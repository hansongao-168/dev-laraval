# Task 2 Review: LayoutTreeDefaults + LayoutTreeValidator

**Reviewer:** Task-scoped gate (read-only)  
**Diff reviewed:** `/var/www/dev-laraval/.superpowers/sdd/task-2-review-package.diff` (gz168 `e74b561`→`263af83`, parent `448cf2c`→`693c79b`)  
**Brief:** `/var/www/dev-laraval/.superpowers/sdd/task-2-brief.md`  
**Report:** `/var/www/dev-laraval/.superpowers/sdd/task-2-report.md`

## Verdict

| Dimension | Result |
|-----------|--------|
| **Spec** | ✅ |
| **Quality** | **Approved** |

Implementation matches Task 2 brief and global M1 layout constraints. Scope is tight; gz168/parent commits align with the plan.

## Global constraints (frozen leaves)

| Constraint | Status | Evidence |
|------------|--------|----------|
| Seven leaves only: header, nav, intro_section, api_section, carriers_section, decisions_section, note | ✅ | `ApiDocLayoutParts::KEYS`; validator membership + duplicate/missing checks |
| Reorder + visibility only; no nesting | ✅ | Flat `nodes` list; no child/parent fields in schema |
| Default: `note.visible = false`; others `true` | ✅ | `LayoutTreeDefaults`: `'visible' => $part !== 'note'` |
| Default: `id === part` | ✅ | Both set to `$part` in defaults |
| Default: `version` 1 | ✅ | `'version' => 1` in defaults and validated output |

## Spec compliance (brief)

| Requirement | Status | Evidence |
|-------------|--------|----------|
| `LayoutTreeDefaults::tree()` return shape (PHPDoc) | ✅ | Matches brief interface |
| `LayoutTreeValidator::validate()` return shape; throws `InvalidArgumentException` | ✅ | Implementation + tests |
| Defaults order from spec | ✅ | Iterates `ApiDocLayoutParts::KEYS` (design-spec order) |
| `version === 1` | ✅ | Strict reject if not `1` |
| `nodes` list, exactly 7 | ✅ | `array_is_list`, non-empty, `count === count(KEYS)` |
| Each node: `part`, `visible`; `part` ∈ KEYS; all parts once | ✅ | Allowed map, `$seen`, missing-part loop |
| Coerce `id` → `part`; coerce `visible` → bool | ✅ | Normalized output; `coerceVisible()` |
| Test `accepts_default_tree` | ✅ | Parent test file matches brief |
| Test `rejects_missing_part` | ✅ | `array_pop` → exception |
| Test `rejects_unknown_part` | ✅ | `part = panel` → exception |
| Commit message `feat(api-doc): add layout tree defaults and validator` | ✅ | gz168 + parent SHAs in report |
| Files under `gz168/ApiDoc/src/Layout/` + parent unit test | ✅ | Diff package |

## Quality

**Strengths**

- Single source of truth for allowed parts via `ApiDocLayoutParts::KEYS` (defaults and validator stay in sync).
- Normalization on validate (output always has canonical `id`, bool `visible`) fits downstream Writer/Service use.
- Duplicate-part and missing-part checks beyond the three brief tests; defensive without scope creep.
- `declare(strict_types=1)`, `final` classes, array-shape PHPDoc consistent with package style.
- Tests use `Tests\TestCase` + `app()` like other ApiDoc unit tests; brief cases copied faithfully.

**Minor (non-blocking)**

- **`id` on input:** Brief lists “each has `id`, `part`, `visible`” alongside “coerce `id` to equal `part`”. Implementation does not require an input `id` key (always emits `id => $part`). Reasonable for M1 coercion; document or add a test in Task 4+ if strict input shape matters for importers.
- **Default-tree assertions:** `accepts_default_tree` only checks version and count (per brief). Optional hardening: assert `note` visibility and `id === part` on all nodes to lock global defaults.
- **Coverage gaps (report acknowledged):** No tests for wrong version, duplicate part, or `id`/visible coercion; acceptable for Task 2, defer to later tasks.
- **`coerceVisible`:** Supports `0`/`1`/`'0'`/`'1'` and `filter_var` booleans—slightly richer than brief’s “to bool”; acceptable normalization.

**Critical**

- None.

## Commit hygiene

- gz168: one feat commit, two new Layout classes only — good.
- Parent: submodule pointer + `LayoutTreeValidatorTest.php` — good.
- No unrelated files in review package.

## Gate decision

| Gate | Result |
|------|--------|
| Task-scoped spec | **PASS** (Spec ✅) |
| Quality (task scope) | **PASS** (Approved) |
| Ready to merge (Task 2) | **YES** |

## Follow-ups (out of scope for this gate)

- Task 3 `PageSkeletonWriter` consumes validated trees.
- Optional unit tests: version ≠ 1, duplicate part, mismatched input `id`, default `note.visible`.
- Align validator error strings with i18n if they become user-facing (report note).
