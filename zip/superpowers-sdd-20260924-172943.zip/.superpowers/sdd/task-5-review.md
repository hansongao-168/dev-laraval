# Task 5 Review: Snapshot layout visual fields

**Reviewer:** Task-scoped gate (read-only)  
**Diff reviewed:** `/var/www/dev-laraval/.superpowers/sdd/task-5-review-package.diff` (gz168 `094cade`→`bcaaeb9`, parent `c50b215`→`8b39b61`)  
**Brief:** `/var/www/dev-laraval/.superpowers/sdd/task-5-brief.md`  
**Report:** `/var/www/dev-laraval/.superpowers/sdd/task-5-report.md`

## Verdict

| Dimension | Result |
|-----------|--------|
| **Spec** | ✅ |
| **Quality** | **Approved** |

Exporter/importer/SkinCopier changes match the brief and global snapshot constraints: three layout columns in export, invalid `layout_editor` fails import, enabled visual + tree re-runs Writer so drifted snapshot `page` is regenerated. Tests cover reject + successful round-trip with literal `=>`.

## Global constraints

| Constraint | Status | Evidence |
|------------|--------|----------|
| Snapshot includes three layout columns | ✅ | `ApiDocExporter.php`: `layout_visual_enabled`, `layout_editor`, `layout_tree` |
| Invalid editor rejected | ✅ | `ApiDocLayoutEditor::tryFrom` → `RuntimeException`; runs before dry-run skip |
| Enabled + tree re-runs Writer on import | ✅ | `shouldRewritePage` → clear tree on first save → `LayoutTreeService::save()` |
| Page cannot drift from tree when visual on | ✅ | Second test: drifted snapshot `page` replaced; `api_doc_part('header'`, `=>`, no `drifted` |

## Spec compliance (brief)

| Requirement | Status | Evidence |
|-------------|--------|----------|
| Export layout fields on template rows | ✅ | Exporter map keys + bool/string/array typing |
| Import validate editor via `tryFrom` | ✅ | Importer foreach template row |
| Import validate tree when non-null | ✅ | `LayoutTreeValidator`; `InvalidArgumentException` → `RuntimeException` |
| Fill model layout fields | ✅ | `$data` includes all three columns |
| Re-run Writer when enabled + tree present | ✅ | Dirty-tree trick + `layoutService->save` |
| SkinCopier layout defaults on create/copy | ✅ | Default `filament_tab` / `false`; tree untouched |
| Feature tests (reject + round-trip) | ✅ | `ApiDocSnapshotLayoutVisualTest.php` |
| Commits | ✅ | gz168 `bcaaeb9`, parent `8b39b61` |

**Tests (2026-09-18):** `ApiDocSnapshotLayoutVisualTest` — **2 passed, 12 assertions**. Related snapshot + SkinCopier suite — **11 passed, 29 assertions**.

## LayoutGate on import vs `js_text` (`ApiDocTemplateJsGate`)

Implementer concern: CLI or unauthenticated import may not apply layout fields because model `saving` hooks restore layout columns when `ApiDocLayoutGate::allows(auth()->user())` is false.

| Layer | `js_text` | Layout visual fields |
|-------|-----------|----------------------|
| Importer | `ApiDocTemplateJsGate::allows` → apply snapshot JS or preserve existing / null for new | Always puts payload layout values in `$data` (no importer gate) |
| Model `ApiDocTemplate` saving | Reverts dirty `js_text` if `!JsGate` | Reverts dirty `layout_*` if `!LayoutGate`; new row → visual off / `filament_tab` / null tree |
| Feature coverage | `ApiDocSnapshotJsTextTest::non_admin_import_preserves_existing_js_text` | Layout snapshot tests only use `actingAsLayoutAdmin()` (super admin + layout-capable pattern) |

**Assessment:** This is **Important, non-blocking**, and largely **intentional** — same defense-in-depth as Filament layout edits (model owns authorization). It is **not** identical to `js_text`: JS uses an **importer-level** policy (strip snapshot JS before fill), while layout relies on **model restore** only. That asymmetry is acceptable for M1 if operators with snapshot import permission also hold layout permission (report follow-up). One extra gap: `shouldRewritePage` is computed from payload and **`LayoutTreeService::save` is not gated at the importer**, so a user without layout permission could still trigger Writer page regeneration after the first save reverts layout flags — edge case worth documenting or guarding in a follow-up (mirror `jsFinal` / skip Writer when `!ApiDocLayoutGate::allows`).

## Quality

**Strengths**

- Validation before dry-run short-circuit: bad editor/tree fails even on dry-run (consistent with fail-fast snapshot UX).
- Writer re-run uses the Task 4 dirty-tree + trusted dual-write pattern correctly (clear `layout_tree` on first save so page lock accepts regeneration).
- Round-trip test asserts `=>` persistence through full hook stack (aligns with Task 4 fix).
- Backward compatible defaults: missing snapshot keys → visual off, `filament_tab`, null tree.
- SkinCopier defaults are minimal and do not copy foreign trees (M1 scope).

### Critical

- None.

### Important (non-blocking)

1. **Layout import authorization vs `js_text`** — Model gate only at import time; no `non_admin_import_preserves_layout_*` test. Document operator requirement (layout permission or super-admin layout capability) or add importer-level skip + test mirroring `ApiDocSnapshotJsTextTest`.
2. **Writer re-run without importer gate check** — `shouldRewritePage` ignores `ApiDocLayoutGate`; consider skipping `layoutService->save` when gate denies (parallel to `$jsFinal`).
3. **Invalid `layout_tree` untested** — Validator path exists; no feature test (brief only required bad editor).

### Minor

1. **Reject test uses `templates[0]`** — Import still fails; targeting by `code` would match the round-trip test style.
2. **SkinCopier layout defaults untested** — Small block; report acknowledges tree not copied by design.

## Commit hygiene

- gz168: single focused commit on exporter, importer, SkinCopier — good.
- Parent: submodule pointer + dedicated feature test file — good.

## Gate decision

| Gate | Result |
|------|--------|
| Task-scoped spec | **PASS** (Spec ✅) |
| Quality (task scope) | **PASS** (Approved) |
| Ready to merge (Task 5 layout visual) | **YES** |

## Follow-ups (optional)

- Importer: `ApiDocLayoutGate::allows` → preserve existing layout columns and skip Writer re-run (parity with `js_text`).
- Feature test: non-layout-capable import preserves existing layout state.
- Feature test: invalid `layout_tree` throws `RuntimeException`.
