# Task 7 Report: Driver `filament_tab` — Sortable layout Tab

**Date:** 2026-09-18  
**Branch:** `feat/apidoc-display-modes` (gz168 + parent)  
**Status:** Complete

## Summary

Edit ApiDoc template gains Tab「布局编排」when `layout_editor === filament_tab`. MVP ↑↓ reorder + visibility toggles write into Livewire `layoutTreeNodes`; **保存布局** calls `LayoutTreeService::save` after `ApiDocLayoutGate` + `layout_visual_enabled` checks. Shared blade `layout-tree-sortable` is ready for Task 8 reuse.

## TDD Flow

| Phase | Result |
| --- | --- |
| GREEN | 3 passed, 19 assertions (`ApiDocTemplateLayoutTabTest`) |
| Related | LayoutLock + LayoutTreeService — 7 passed, 34 assertions |
| Pint | Passed |

## Files Created / Updated

| Path | Role |
| --- | --- |
| `gz168/ApiDoc/resources/views/filament/components/layout-tree-sortable.blade.php` | Reusable ↑↓ / visible / save UI |
| `gz168/ApiDoc/src/Filament/Resources/ApiDocTemplateResource.php` | Tab「布局编排」+ `layout_editor` live |
| `gz168/ApiDoc/src/Filament/Resources/ApiDocTemplateResource/Pages/EditApiDocTemplate.php` | `layoutTreeNodes` + move/toggle/`saveLayout` |
| `tests/Feature/ApiDoc/ApiDocTemplateLayoutTabTest.php` | Reorder persist; visual gate; toggle persist |

## Implementation Notes

- Tab visible via `Get` when editor is `filament_tab` (create hidden).
- Edits require `layout_visual_enabled`; otherwise blade shows「请先启用可视化布局」and mutators no-op.
- `saveLayout` notifies danger on missing layout permission (no write); warning if visual off; success after dual-write + `refreshFormData(['body_parts','layout_tree'])`.
- Avoided Livewire hook name `hydrateLayoutTreeNodes` (conflicts with property hydrate); used `syncLayoutTreeNodesFromRecord`.

## Test Cases

1. **admin_can_reorder_layout_via_livewire_and_persist_tree_and_page** — moveDown header↔nav; save; tree + page order match.
2. **save_layout_requires_visual_enabled** — reorder ignored when visual false; tree unchanged.
3. **toggle_visibility_updates_working_nodes_before_save** — hide carriers; page omits carriers_section call.

## Commits

| Repo | SHA | Message |
| --- | --- | --- |
| gz168 | `a3dd2b8` | feat(api-doc): filament_tab layout editor |
| parent | `0e500f2` | feat(api-doc): filament_tab layout editor |

Report under `.superpowers/sdd/` (gitignored). No push.

## Verification Command

```bash
php artisan test --compact tests/Feature/ApiDoc/ApiDocTemplateLayoutTabTest.php
```

**Evidence (2026-09-18):** 3 passed, 19 assertions.

## Concerns / Follow-ups

- Drag-and-drop deferred (MVP ↑↓ acceptable per brief); Task 8 can share the blade.
- Livewire gate-denial mid-session is awkward to feature-test without roles schema (Edit `authorizeAccess` runs on hydrate); gate early-return is implemented; model restore already covered in `LayoutTreeServiceTest`.
- Enabling default-hidden `note` via layout can break Edit preview (`note.blade.php` expects richer data); use carriers/etc. for visibility tests until preview is hardened.
- Boost `search-docs` unavailable in this session; Filament Schema `View` usage mirrored from installed Filament 5 sources.
