# Final Review R2: ApiDoc Display Modes

**Branch:** `feat/apidoc-display-modes`  
**Parent range:** `6e72c500` → `be0d5e32`  
**gz168 range:** `40f8c31` → `064275f`  
**Diff package:** `.superpowers/sdd/final-review-package-r2.diff`  
**Prior review:** `.superpowers/sdd/final-review.md` (**Request changes**)  
**Fix report:** `.superpowers/sdd/final-fix-report.md`  
**Spec:** `docs/dev-laraval/superpowers/specs/2026-09-14-apidoc-display-modes-design.md`  
**Verification:** `php artisan test --compact tests/Feature/ApiDoc/ tests/Unit/ApiDoc/` → **30 passed** (73 assertions); Create/Edit sync filters green

---

## Overall verdict

**Approve with nits**

All three Important merge blockers from R1 are resolved. Spec §4.1 admin i18n (EN tabs + body format editors) and Filament default→`default_locale` sync coverage are in place. Remaining items are deferred polish / non-blocking nits from R1.

---

## Important items — re-check

| # | R1 finding | Status | Evidence |
| --- | --- | --- | --- |
| 1 | EN tab always present on `LocalizedKeyValue` | ✅ **Resolved** | `LocalizedKeyValueTabs::pair` always builds 法文 \| 中文 \| 英文; `$enLabel ?? defaultEnLabel($frLabel)` (`064275f`) |
| 2 | `LocalizedBodyFields` wired at body call sites | ✅ **Resolved** | Spreads on Paras `text`, Notes `body`, ParamRows `description`, Decision `body`, Quickstart `description`; models + migration `content_format` |
| 3 | Filament Create/Edit sync tests for `default_locale` | ✅ **Resolved** | `edit_page_default_syncs_settings_locale` + `create_page_default_syncs_settings_locale` exercise Livewire save/create → single default + `ApiDocSetting.default_locale`; page hooks `afterSave`/`afterCreate` → `syncDefaultAndFlush()` |

---

## Plan alignment (delta vs R1)

| Spec / plan item | R1 | R2 |
| --- | --- | --- |
| Admin Tabs 法文 \| 中文 \| **英文** | ❌ | ✅ EN default-on in component |
| Body: `content_format` + Markdown/Rich per locale | ❌ | ✅ wired at body owners |
| Feature: Filament page-hook default sync | partial | ✅ Create + Edit Livewire tests |
| Other R1 ✅ items (modes, resolver, front, cache, settings) | ✅ | ✅ unchanged / still green |

---

## Critical findings

_None._

---

## Important findings

_None remaining from R1._

---

## Minor findings (nits — do not block merge)

1. **`->required()` forces all three locales including EN** — Spec §4.1 / §1.1: 不强制三语齐全. Chained `required()` still marks FR+ZH+EN inputs required. Pre-existing for FR/ZH; EN inclusion slightly widens the mismatch. Prefer “at least one locale” or only primary, later.
2. **`ensureInvariant()` unused / untested** — R1 minor; defer.
3. **Seeder does not clear rival `is_default` on non-seed rows** — R1 minor; defer.
4. **`SeedFromHtmlCommand --fresh` omits `api_doc_display_modes`** — R1 minor; defer.
5. **Custom mode cache keys on non-tagged stores** — Spec §5.4 already scoped; defer.
6. **Edit Repeater fill smoke** — still worth one manual open; not automated.
7. **Alpine state still named `lang`; layout hard-codes FR/ZH/EN** — R1 Task 5 minors.
8. **Intro nested paragraphs in `ApiDocSectionResource`** — still `LocalizedKeyValue` TextInputs (JSON intro shape, no `content_format` column). Out of R1 Important #2 scope; revisit if intro bodies need format editors.
9. **Dirty/untracked WIP** called out in fix report (CSS/views, Section Create/Edit WIP, etc.) — keep out of this merge; not part of the r2 package contract.

---

## Strengths (R2)

- EN tab cannot regress by omitting `enLabel` at call sites.
- Body admin UI now matches renderer’s `localizeBody(..., $content_format)`.
- Default sync is asserted through the real Filament Create/Edit path, not only manual resolver calls.
- Suite grew to 30 tests; focused sync tests pass with 12 assertions.

---

## Recommended merge gate

Ship as-is for display-modes. Optionally before or after merge: one manual Edit of a display-mode locale Repeater; later tighten `required()` vs Spec “不强制三语齐全.”
