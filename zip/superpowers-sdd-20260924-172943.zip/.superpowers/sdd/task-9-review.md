# Task 9 Review: Driver `grapesjs` — Layout editor shell

**Reviewer:** Task-scoped gate (read-only)  
**Diff reviewed:** `/var/www/dev-laraval/.superpowers/sdd/task-9-review-package.diff` (gz168 `1b75319`→`a5e8058`, parent `25a0d90`→`767084f`)  
**Brief:** `/var/www/dev-laraval/.superpowers/sdd/task-9-brief.md`  
**Report:** `/var/www/dev-laraval/.superpowers/sdd/task-9-report.md`

---

## Global constraints

| Constraint | Status | Evidence |
|------------|--------|----------|
| **7 frozen leaves only** | ✅ | JS `ALLOWED_PARTS` matches `ApiDocLayoutParts::KEYS` (7); `BlockManager.getAll().reset()` then add each once; `normalizeLayoutNodes` / `applyLayoutFromGrapes` filter to allowed parts; `LayoutTreeValidator` still enforces exactly 7 unique parts on apply/save. |
| **Read-only HTML preview** | ✅ | Side panel iframe `sandbox=""` + `srcdoc` from `ApiDocHtmlSanitizer::sanitizeHtml`; empty HTML falls back to readonly textarea of part source (DB `body_parts` or package Blade file). No in-canvas HTML editing of part bodies (`editable: false`, `stylable: false`). |
| **No free DOM / custom components** | ✅ (with notes) | Only type `api-doc-layout-part`; `storageManager: false`; illegal blocks removed on `block:drag:stop` / `component:add`. Default Grapes panels cleared. Server reject path via validator. See Important: aggressive `component:add` + duplicate clones. |
| **Assets admin-only** | ✅ | Grapes Vite entry `@vite(['resources/js/api-doc-layout-grapes.js'])` only inside `isGrapesEditor()` branch of admin layout page; not on public `/api-doc`. Plan wording: assets only on admin layout page. |
| **Save via `LayoutTreeService`** | ✅ | `saveLayout()` still `app(LayoutTreeService::class)->save(...)` after gate + visual flags; Grapes `applyLayoutFromGrapes` only mutates Livewire working copy + validates, does not persist. |

---

## Spec compliance (brief)

| Requirement | Status | Evidence |
|-------------|--------|----------|
| `grapesjs` npm dep + Vite entry | ✅ | `package.json` `grapesjs@^0.23.6`; `resources/js/api-doc-layout-grapes.js` imports package `grapes-editor.js`; `vite.config.js` input added. |
| `grapes-editor.js` — 7 blocks, `storageManager: false` | ✅ | Init options + BlockManager registration. |
| Load tree order + `visible` | ✅ | `loadNodesOntoCanvas` from `data-layout-tree` / options; `display:none` + `partVisible` trait. |
| 「应用到树」→ Livewire nodes; reject unknown | ✅ | Apply button → `applyLayoutFromGrapes`; illegal components removed in JS; PHP filters + `LayoutTreeValidator`. |
| Selected part → read-only preview | ✅ | `selectedPart` + sanitized iframe / readonly source (file fallback when DB empty). |
| Blade canvas root + hooks | ✅ | `#api-doc-grapes-root`, `wire:ignore`, apply/save buttons, gate/`layout_visual_enabled` for write. |
| PHPUnit smoke without browser Grapes | ✅ | `grapesjs_editor_loads_root_and_save_layout_persists_tree` + `grapesjs_selected_part_preview_reads_body_parts`; `withoutVite()`. |
| Commits | ✅ | gz168 `a5e8058`, parent `767084f` — message matches brief. |

**Brief deltas (non-blocking):**

- Brief example `call('saveLayout', $tree)` — implementation correctly uses `applyLayoutFromGrapes($nodes)` then parameterless `saveLayout()` (matches Task 8 page API).
- Preview uses sanitized `body_parts` / Blade file, not full `ApiDocTemplateViewResolver` front render — report documents; aligns with design “DB 或文件回退”.

**Tests (verified 2026-09-18):**

```text
php artisan test --compact tests/Feature/ApiDoc/ApiDocTemplateLayoutEditorPageTest.php
# 5 passed, 20 assertions
```

Matches report.

---

## Strengths

- **Constraint-aligned shell** — frozen part set, no storage, no default block palette left after reset, persistence still single-pathed through `LayoutTreeService`.
- **Defense in depth** — client strip of illegal components + server `LayoutTreeValidator` on apply; gate/`layout_visual_enabled` on apply and save.
- **Safe preview** — empty `sandbox` iframe + existing sanitizer; admin-only page load for the ~1.1 MB Grapes chunk.
- **Testable without JS runtime** — Livewire calls cover load root, apply reorder, persist, and preview HTML.

---

## Issues

### Critical (must fix)

_None._

### Important (non-blocking)

1. **`component:add` may strip nested label markup** — Handler removes any component that is not `api-doc-layout-part` with an allowed `data-part`. Grapes typically parses `content: '<strong>…</strong><code>…</code>'` into child components, which would be deleted on add. Prefer removing only **wrapper-level** illegals (e.g. parent is canvas wrapper), or use non-parsed label (`components: []` + custom view / attributes only).
2. **Visibility toggle UI missing** — Spec/driver goal is 排序 + 显隐, and a `partVisible` trait exists, but `panels: { defaults: [] }` hides Trait/Block panels. Users can load `display:none` from the tree and apply visibility if somehow set, but cannot comfortably toggle visibility in the Grapes UI. Add a minimal traits (or custom) control, or a small Livewire toggle when a part is selected.
3. **Duplicates still possible on canvas** — Report acknowledges; clone/drag can produce duplicate allowed parts; apply fails validator (soft). Optional: reject duplicate `data-part` on `component:add` / `block:drag:stop`.
4. **Read-only gate does not lock canvas** — When `canWrite` is false, apply/save are disabled in Blade/JS, but the canvas can still be rearranged visually until refresh. Low risk (no persist); optional `editor.setDragMode` / destroy interactions when `!canWrite`.

### Minor (nice to have)

1. **No ViewResolver-backed preview** — Acceptable for M1; full front sample data remains a follow-up.
2. **Grapes as production `dependencies`** — Brief allows; could be `devDependencies` if build always runs in CI (cosmetic).
3. **Large Grapes chunk (~1.1 MB)** — Acceptable admin-only; code-split later if needed.
4. **Apply button via `document.querySelector`** — Fine for single root; prefer scoping under the Livewire host if the page ever embeds twice.

---

## Commit hygiene

- gz168: focused shell (editor JS + blade + page methods) — appropriate.
- Parent: submodule bump + npm/Vite entry + feature tests — appropriate split.
- Message matches brief Step 3.

---

## Dual verdict (summary)

| Gate | Verdict |
|------|---------|
| **Part 1 — Spec compliance** | ✅ **Approved** — GrapesJS shell meets brief: Vite/`grapesjs` wiring, 7 frozen blocks, `storageManager: false`, apply→Livewire tree, unknown reject, read-only sanitized preview, save via `LayoutTreeService`, PHPUnit smoke without browser JS. Global assets-on-admin-page and no free-DOM intent satisfied for M1 shell. |
| **Part 2 — Code quality** | ✅ **Approved** with follow-ups — Important: tighten `component:add` so labels are not stripped; expose visibility controls despite empty default panels; optional duplicate prevention and canvas lock when `!canWrite`. No critical defects. |

---

## Gate decision

| Gate | Result |
|------|--------|
| Task-scoped spec | **PASS** (Part 1 ✅) |
| Quality (task scope) | **PASS** (Part 2 Approved) |
| Ready to merge (Task 9 `grapesjs` layout editor shell) | **YES** |

---

## Follow-ups (optional)

- Scope illegal-component removal to top-level canvas children only (preserve part labels).
- Show visibility trait/UI (or selected-part Livewire toggle) so grapes driver can 显隐 without another editor.
- Reject duplicate `data-part` on canvas before apply.
- Disable canvas drag when `data-can-write="0"`.
