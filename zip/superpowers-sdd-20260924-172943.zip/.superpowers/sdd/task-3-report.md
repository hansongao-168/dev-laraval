# Task 3 Report: PageSkeletonWriter

**Date:** 2026-09-18  
**Branch:** `feat/apidoc-display-modes` (gz168 + parent)  
**Status:** Complete

## Summary

Implemented `PageSkeletonWriter` to turn a validated layout tree into a classic-isomorphic `body_parts.page` Blade skeleton. Visible leaves emit exact `api_doc_part(...)` argument arrays from `api-doc-page.blade.php`; `intro_section` / `api_section` share one `@foreach` slot with inlined `$__layout_intro` / `$__layout_api` booleans; output is sanitized via `ApiDocHtmlSanitizer::sanitizeBodyParts` before return.

## TDD Flow

| Phase | Result |
| --- | --- |
| RED | 3 errors — `PageSkeletonWriter` class not found |
| GREEN | 3 passed, 5 assertions |
| Pint | Passed (`vendor/bin/pint --dirty --format agent`) |

## Files Created

| Path | Role |
| --- | --- |
| `gz168/ApiDoc/src/Layout/PageSkeletonWriter.php` | `write(array $tree): string` skeleton generator |
| `tests/Unit/ApiDoc/PageSkeletonWriterTest.php` | Unit tests per task brief |

## Implementation Notes

### Shell

- Outer `<div>` → optional header → `.wrap` → optional nav → `<main id="main">` → content → classic footer → toast.
- Wrap/main open lazily on first need; footer/toast always present for classic isomorphism.

### Sections slot

- Pre-scan intro/api visibility across the full tree.
- Emit foreach once at the first intro/api node position when either is visible; skip the second.
- Inline `@if (true)` / `@if (false)` literals (not PHP variables).
- Relative order of intro vs api in the tree is ignored.

### Other parts

| Part | Behavior |
| --- | --- |
| `header` / `nav` / `carriers_section` | Exact classic `api_doc_part` argument arrays |
| `decisions_section` | Emitted only when visible; keeps `@if (!empty($data['settings']['show_decisions']))` wrapper |
| `note` | Omitted when `visible:false` (default); args `['note' => $data['note'] ?? [], 'lang' => $lang]` (classic page has no note call) |

### Sanitization

- Return path: `sanitizeBodyParts(['page' => $html])['page']`.
- DOM serialization entity-encodes `=>` to `=&gt;`; Writer restores with `str_replace('=&gt;', '=>', …)` so Blade arrays remain valid.

## Test Cases (brief)

1. **orders_non_section_parts_and_hides_note_by_default** — header present, note absent, header before nav.
2. **hides_carriers_when_not_visible** — carriers call omitted when `visible:false`.
3. **omits_sections_loop_when_both_intro_and_api_hidden** — no `@foreach ($data['sections']` when both hidden.

## Commits

| Repo | SHA | Message |
| --- | --- | --- |
| gz168 | `bb70ce2` | feat(api-doc): generate page skeleton from layout tree |
| parent | `941fa9f` | feat(api-doc): generate page skeleton from layout tree |

Parent commit includes submodule pointer update + test file.

## Verification Command

```bash
php artisan test --compact tests/Unit/ApiDoc/PageSkeletonWriterTest.php
```

## Out of Scope / Follow-ups

- `LayoutTreeService` dual-write (Task 4) consumes this Writer next.
- No explicit unit coverage yet for partial intro/api visibility, decisions hide, or note visible.

## Concerns

- `ApiDocHtmlSanitizer` / DOM path entity-encodes `=>`; Writer compensates with a targeted `=&gt;` → `=>` restore. Prefer fixing sanitizer for Blade-bearing `page` parts later if other entities become an issue.
- Page-level `note` argument array is inferred (classic shell has no note); confirm when note visibility is enabled in UI.
