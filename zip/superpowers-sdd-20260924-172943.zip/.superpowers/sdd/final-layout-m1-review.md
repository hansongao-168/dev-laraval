# Final Review: ApiDoc Layout Visual M1

**Feature:** Shared `layout_tree` dual-write + `page` lock + three editor drivers (`filament_tab`, `livewire_page`, `grapesjs`)  
**Diff packages:**  
- gz168 `f2c3926..a5e8058` — `.superpowers/sdd/final-layout-m1-gz168-review-package.diff`  
- parent `7064032..767084f` — `.superpowers/sdd/final-layout-m1-parent-review-package.diff`  
**Spec:** `docs/dev-laraval/superpowers/specs/2026-09-18-apidoc-layout-visual-m1-design.md`  
**Plan:** `docs/dev-laraval/superpowers/plans/2026-09-18-apidoc-layout-visual-m1.md`  
**Verification (Task 10 report):** layout slice **23/23** passed, **80** assertions (not re-run in this review)

---

## Overall verdict

**Approve with nits**

M1 delivers the frozen 7-leaf kernel, dual-write + page lock rail, permission gate, snapshot round-trip, front fail-soft resolve path, and all three editor shells on a shared `LayoutTreeService` save path. Remaining items from per-task reviews are Important/Minor follow-ups; none are Critical merge blockers for the classic skin path covered by the suite.

---

## Plan / spec alignment

| Spec / plan item | Status | Notes |
| --- | --- | --- |
| Columns `layout_visual_enabled` / `layout_editor` / `layout_tree` | ✅ | Migration + fillable/casts; factory defaults |
| Permission `api-doc.templates.layout` + seeder | ✅ | `ApiDocPermission::TemplatesLayout`; Chinese label |
| Tree schema v1: exactly 7 unique parts, reorder + `visible` | ✅ | `LayoutTreeValidator` + `LayoutTreeDefaults` (`note` hidden) |
| Dual-write: tree → `PageSkeletonWriter` → `body_parts.page` | ✅ | `LayoutTreeService::save` + cache flush; `=&gt;` restore |
| Sections slot: intro/api share foreach; relative order ignored | ✅ | Writer emits one `@foreach` with per-branch guards |
| `visible:false` omits call (no Blade comment wrap) | ✅ | Writer skips invisible leaves |
| Page lock when visual enabled (form + model) | ✅ | Textarea disabled/dehydrated; `mutateFormDataBeforeSave`; model `trustedLayoutDualWrite` |
| Gate restore of layout fields without permission | ✅ | Model `saving`; covered in `LayoutTreeServiceTest` |
| Runtime: visual on → DB page / fail-soft Writer; off → ignore tree | ✅ | `resolveEffectivePage` + ViewResolver `page` hook |
| Snapshot export/import validate editor + tree; Writer on enabled | ✅ | Importer fail-fast; dirty-tree trick for dual-write |
| SkinCopier / create defaults | ✅ (delta) | Defaults `filament_tab` / false / null tree; plan “create defaults” — not a full 创建副本 copy of source layout columns (see Minor) |
| Driver `filament_tab` Sortable ↑↓ + visibility + save | ✅ | Shared blade; Edit Livewire methods |
| Driver `livewire_page` full-width page + structure preview | ✅ | Shared route entry; action on list/edit/view |
| Driver `grapesjs` 7 blocks + read-only HTML preview; admin Vite only | ✅ (gap) | Shell + apply/save; **显隐 UI incomplete** (Important) |
| Front: carriers hidden ⇒ no carriers marker | ✅ | `ApiDocTemplateLayoutRenderTest` |
| Tests: unit validator/writer/gate + feature lock/tab/page/snapshot | ✅ | Task 10: 23 tests / 80 assertions |
| `LayoutEditorDriver` interface | ⚠️ | Spec suggested; not introduced — UIs call Service directly (acceptable) |

Unrelated parent dirty/untracked files outside these packages are out of scope.

---

## Strengths

- **Single persistence kernel** — Validator → Writer → `LayoutTreeService::save` → model hooks; three UIs do not invent alternate write paths.
- **Page lock is defense-in-depth** — Filament dehydrate + Edit mutate + model restore with gated `trustedLayoutDualWrite` (Task 4 `saveQuietly` pitfall fixed).
- **Writer contracts match design** — sections slot simplification, omit-on-hidden, classic-shaped wrap/main/footer/toast, sanitizer + `=>` restore so Blade arrays survive DOM serialization.
- **Fail-soft front path** — empty stored `page` with visual on regenerates from tree without writing (ViewResolver); classic regression test forces this path.
- **Grapes boundary mostly right** — frozen part set, no storage, illegal strip + server re-validate, sanitized `sandbox=""` preview, assets only on admin layout page.
- **Shared Livewire/Grapes entry** — one page slug branches on `layout_editor`; avoids dual-route drift.
- **Task reviews closed Criticals early** (Service save hooks) and kept Important items explicitly deferred rather than hidden.

---

## Issues

### Critical (Must Fix)

_None._

### Important (Should Fix — not merge-blocking for classic M1)

1. **Grapes driver: visibility toggle UI missing**  
   - Files: `gz168/ApiDoc/resources/js/layout/grapes-editor.js`, `template-layout-editor.blade.php`  
   - Issue: Spec requires 排序 + 显隐 for grapes; `partVisible` trait exists but `panels: { defaults: [] }` hides Trait UI. Grapes branch has no Livewire toggle fallback. Users can preserve loaded visibility and reorder/apply, but cannot comfortably 显隐 in-canvas.  
   - Why: Breaks “三驱动同能力” for the grapes shell (other drivers have toggles).  
   - Fix: Minimal traits panel / custom control, or selected-part Livewire toggle on the grapes branch.  
   - **Triage:** Follow-up before calling grapes feature-complete; **do not block merge** if ops can use `filament_tab` / `livewire_page` for visibility on the same skin.

2. **Grapes `component:add` may strip nested label markup**  
   - File: `grapes-editor.js`  
   - Issue: Handler removes any non–`api-doc-layout-part` component; Grapes often parses `content: '<strong>…</strong><code>…</code>'` into children that get deleted.  
   - Fix: Strip only wrapper-level illegals, or use attribute-only labels without nested HTML.  
   - **Triage:** Follow-up; soft apply failure / empty labels, not data corruption (server validator still guards save).

3. **Importer LayoutGate vs `js_text` asymmetry + ungated Writer re-run**  
   - File: `ApiDocImporter.php` (+ model restore)  
   - Issue: JS uses importer-level `$jsFinal`; layout always fills payload then relies on model restore. `shouldRewritePage` → `LayoutTreeService::save` runs even when gate denies, and can still rewrite `body_parts.page` after layout columns are restored.  
   - Why: Defense-in-depth gap for imports by users with import but without layout permission (or CLI `auth()` null).  
   - Fix: Mirror `js_text`: skip layout fill + skip Writer when `!ApiDocLayoutGate::allows`; add non-admin import test.  
   - **Triage:** Follow-up; acceptable for M1 if snapshot import operators are layout-capable / super-admin (current test pattern).

4. **`assertPartAvailable('page')` ignores tree regeneration for file-less skins**  
   - File: `ApiDocPage.php`  
   - Issue: Pre-render check requires non-empty `bodyParts.page` or an existing Blade view. Visual-on + empty DB page + tree still works for **classic** (file exists); custom skins without file fallback can throw before ViewResolver fail-soft.  
   - Fix: Teach assert about `resolveEffectivePage` / visual+tree, or resolve effective page earlier.  
   - **Triage:** Follow-up before shipping file-less visual skins; **not blocking** classic M1.

5. **Duplicated Livewire layout mutators (Edit vs LayoutEditorPage)**  
   - Files: `EditApiDocTemplate.php`, `ApiDocTemplateLayoutEditorPage.php`  
   - Issue: ~80 lines of move/toggle/sync/save duplicated; grapes added only on the page class — drift risk.  
   - Fix: Shared trait/concern.  
   - **Triage:** Hygiene follow-up; behavior currently consistent.

### Minor (Nice to Have)

1. **`ApiDocLayoutGate` roles-table workaround** — `Schema::hasTable('roles')` fail-closed on non–super/admin path; unique vs `ApiDocAuthorization`. Safe in prod; weakens gate unit deny semantics when roles absent. Converge or document later.  
2. **Grapes canvas not locked when `!canWrite`** — Apply/save disabled; drag still possible visually until refresh. Optional `setDragMode` / disable.  
3. **Grapes duplicate parts on canvas** — Soft-fail on apply via validator; optional client-side duplicate reject.  
4. **SkinCopier vs spec “复制三列”** — Create path sets defaults; does not copy source layout state. Aligns with plan Task 5 wording more than strict spec; document or copy when a true 创建副本 flow appears.  
5. **No formal `LayoutEditorDriver` interface** — Spec suggestion skipped; Service-centric design is fine.  
6. **Per-render DB lookup in ViewResolver** — Extra `ApiDocTemplate` query for `page`; pass model/DTO later.  
7. **Test gaps** — Invalid `layout_tree` import throw; Filament layout-gate deny on Edit form; action hidden for `filament_tab`; page save-requires-visual; grapes visibility; `assertPartAvailable` file-less case.  
8. **Grapes as production `dependencies` / large chunk** — Admin-only acceptable for M1.

---

## Deferred backlog triage (from progress + task reviews)

| Theme | Must fix before merge? | Disposition |
| --- | --- | --- |
| LayoutGate roles-table workaround | No | **Defer** — Minor #1 |
| Importer LayoutGate vs `js_text` + Writer re-run | No* | **Defer** — Important #3 (*unless import is routinely run without layout permission) |
| Grapes `component:add` stripping labels | No | **Defer** — Important #2 |
| Grapes visibility traits / UI | No** | **Defer** — Important #1 (**required for grapes parity follow-up) |
| Edit/Layout page Livewire duplication | No | **Defer** — Important #5 |
| `assertPartAvailable` file-less skins | No*** | **Defer** — Important #4 (***before non-classic visual skins) |

---

## Recommendations

- Merge M1 as shipped; track Important #1–#4 as a small follow-up PR (grapes 显隐 + `component:add` scope, importer gate parity, `assertPartAvailable`).
- Prefer extracting a `InteractsWithLayoutTree` trait before adding more editor surface area (M2).
- When introducing file-less custom skins with visual layout, fix Important #4 in the same change.
- Optional: run full `php artisan test --compact` once before release (Task 10 asked; not required by this review).

---

## Assessment

**Ready to merge?** **Approve with nits**

Kernel, lock rail, snapshot, front classic path, and three shells meet the M1 design intent. Nits are known deferred Important/Minor items; none warrant **Changes requested** for this branch gate.
