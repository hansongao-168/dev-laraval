### Task 7: Driver `filament_tab` — Sortable layout Tab

**Files:**
- Modify: `gz168/ApiDoc/src/Filament/Resources/ApiDocTemplateResource.php`
- Create: `gz168/ApiDoc/resources/views/filament/components/layout-tree-sortable.blade.php`
- Modify: `EditApiDocTemplate.php` — `saveLayoutTree` action / form Hidden `layout_tree`
- Test: `tests/Feature/ApiDoc/ApiDocTemplateLayoutTabTest.php`

**UI behavior:**
- Tab「布局编排」visible when `layout_editor === filament_tab` (Get) OR always visible but content explains switch — **spec: mount driver by editor**; Tab visible iff editor is `filament_tab` and user can view template.
- Alpine + SortableJS (use CDN in blade **or** Filament's existing sortable if present — check Filament 5 docs; if none, Alpine `@sortable` via `sortablejs` npm already used by Filament — prefer `wire:sortable` Livewire plugin if project has it; else Alpine list with up/down buttons **minimum viable** + drag if Sortable available).
- **MVP acceptable:** list with ↑↓ buttons + visibility toggles writing into Livewire property `layoutTreeNodes`, Save button calls `LayoutTreeService::save` then refresh. Drag-and-drop is preferred but ↑↓ satisfies M1 if Sortable integration blocks.
- Require `layout_visual_enabled` true to enable edits; if false, show hint「请先启用可视化布局」.

- [ ] **Step 1: Feature smoke** — admin opens Edit, sees layout tab fields; calling save layout with reordered nodes updates `layout_tree` and page string order.

- [ ] **Step 2: Implement + PASS + commit**

```bash
git commit -m "feat(api-doc): filament_tab layout editor"
```

---

