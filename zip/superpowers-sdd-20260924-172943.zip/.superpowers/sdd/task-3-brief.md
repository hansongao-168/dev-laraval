### Task 3: PageSkeletonWriter

**Files:**
- Create: `gz168/ApiDoc/src/Layout/PageSkeletonWriter.php`
- Test: `tests/Unit/ApiDoc/PageSkeletonWriterTest.php`

**Interfaces:**
```php
final class PageSkeletonWriter
{
    /**
     * @param  array{version:int,nodes:list<array{id:string,part:string,visible:bool}>}  $tree
     */
    public function write(array $tree): string;
}
```

**Produces:** HTML string matching classic shell. Exact fragments to emit:

Header call (if visible):
`{!! api_doc_part('header', ['settings' => $settings, 'lang' => $lang, 'mode' => $mode, 'modes' => $modes, 'ui' => $ui]) !!}`

Nav:
`{!! api_doc_part('nav', ['nav' => $data['nav'] ?? [], 'lang' => $lang]) !!}`

Sections slot (if intro and/or api visible):
```blade
@foreach ($data['sections'] as $section)
    @if (!empty($section['is_intro']))
        @if ($__layout_intro)
            {!! api_doc_part('intro_section', ['section' => $section, 'lang' => $lang, 'quickstart' => $data['quickstart'] ?? [], 'ui' => $ui]) !!}
        @endif
    @else
        @if ($__layout_api)
            {!! api_doc_part('api_section', ['section' => $section, 'lang' => $lang, 'ui' => $ui]) !!}
        @endif
    @endif
@endforeach
```
Where `$__layout_intro` / `$__layout_api` are inlined as `true`/`false` literals in generated PHP (Writer substitutes booleans into the string as `true`/`false`).

Carriers / decisions / note — same argument arrays as classic `api-doc-page.blade.php`. Decisions keep wrapping `@if (!empty($data['settings']['show_decisions']))` **and** only emit that block when decisions node visible.

Shell order algorithm:
1. Walk nodes in order.
2. When encountering `intro_section` or `api_section`, if sections slot not yet emitted and at least one of intro/api is visible in the **full tree**, emit the foreach once at the position of the **first** of {intro, api} in the tree; skip the second when reached.
3. Other parts: emit at their position if visible.

- [ ] **Step 1: Failing tests**

```php
#[Test]
public function orders_non_section_parts_and_hides_note_by_default(): void
{
    $html = app(PageSkeletonWriter::class)->write(LayoutTreeDefaults::tree());
    $this->assertStringContainsString("api_doc_part('header'", $html);
    $this->assertStringNotContainsString("api_doc_part('note'", $html);
    $posHeader = strpos($html, "api_doc_part('header'");
    $posNav = strpos($html, "api_doc_part('nav'");
    $this->assertTrue($posHeader < $posNav);
}

#[Test]
public function hides_carriers_when_not_visible(): void
{
    $tree = LayoutTreeDefaults::tree();
    foreach ($tree['nodes'] as &$n) {
        if ($n['part'] === 'carriers_section') {
            $n['visible'] = false;
        }
    }
    unset($n);
    $html = app(PageSkeletonWriter::class)->write($tree);
    $this->assertStringNotContainsString("api_doc_part('carriers_section'", $html);
}

#[Test]
public function omits_sections_loop_when_both_intro_and_api_hidden(): void
{
    $tree = LayoutTreeDefaults::tree();
    foreach ($tree['nodes'] as &$n) {
        if (in_array($n['part'], ['intro_section', 'api_section'], true)) {
            $n['visible'] = false;
        }
    }
    unset($n);
    $html = app(PageSkeletonWriter::class)->write($tree);
    $this->assertStringNotContainsString('@foreach ($data[\'sections\']', $html);
}
```

- [ ] **Step 2: Implement Writer + PASS tests**

Wrap output in classic outer `<div>…toast…</div>` structure from `resources/views/front/api-doc-page.blade.php`. Pass generated string through `ApiDocHtmlSanitizer::sanitizeBodyParts(['page' => $html])['page']` before return (or sanitize in Service only — **do sanitize inside Writer** so callers always get safe HTML).

- [ ] **Step 3: Commit**

```bash
git commit -m "feat(api-doc): generate page skeleton from layout tree"
```

---

