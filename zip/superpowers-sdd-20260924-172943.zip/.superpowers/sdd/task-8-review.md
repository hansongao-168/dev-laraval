# Task 8 Review: Driver `livewire_page` — Layout editor page

**Reviewer:** Task-scoped gate (read-only)  
**Diff reviewed:** `/var/www/dev-laraval/.superpowers/sdd/task-8-review-package.diff` (gz168 `a3dd2b8`→`1b75319`, parent `0e500f2`→`25a0d90`)  
**Brief:** `/var/www/dev-laraval/.superpowers/sdd/task-8-brief.md`  
**Report:** `/var/www/dev-laraval/.superpowers/sdd/task-8-report.md`

**Review note:** GrapesJS canvas / Vite entry is **explicitly out of scope** for Task 8; `#api-doc-grapes-root` placeholder is **acceptable** pending Task 9.

---

## Global constraints

| Constraint | Status | Evidence |
|------------|--------|----------|
| **7 frozen leaves only** | ✅ | Working copy synced from record/defaults; mutators only reorder or toggle `visible`; persist builds `{ version: 1, nodes: … }` → `LayoutTreeService` + validator (same as Task 7). |
| **Save via `LayoutTreeService`** | ✅ | `saveLayout()` calls `app(LayoutTreeService::class)->save($this->template, $tree)` then `refresh()` + `syncLayoutTreeNodesFromRecord()`. |
| **Gate on write** | ✅ | Blade passes `canWrite` from gate + `layout_visual_enabled`; Livewire `canMutateLayoutTree()` on moves/toggles; `saveLayout()` danger notification when gate denies. |
| **↑↓ MVP OK** | ✅ | Reuses `layout-tree-sortable` with `moveLayoutNodeUp` / `moveLayoutNodeDown` (no drag-and-drop). |

---

## Spec compliance (brief)

| Requirement | Status | Evidence |
|-------------|--------|----------|
| `ApiDocTemplateLayoutEditorPage` + blade view | ✅ | New page class + `template-layout-editor.blade.php`. |
| Slug / route param `template` (id or code) | ✅ | `api-doc-templates/{record}/layout-editor`; `mount(int\|string $record)` + `resolveTemplate()` (numeric id, else `code`). |
| `mount`: view auth, load template, init nodes | ✅ | `abort_unless(ApiDocTemplateResource::canView(...), 403)`; `syncLayoutTreeNodesFromRecord()` from `layout_tree` or `LayoutTreeDefaults::tree()`. |
| Left: `layout-tree-sortable` | ✅ | `@include('gz168-api-doc::filament.components.layout-tree-sortable', …)` with explicit `nodes`, `visualEnabled`, `canWrite`. |
| Right: visible part labels preview | ✅ | `getVisiblePartLabelsProperty()` + ordered list in blade. |
| `saveLayout`: gate + visual enablement | ✅ | Soft notifications (aligned with Task 7 tab); no persist when denied. |
| Resource action「打开布局编排」 | ✅ | `openLayoutEditorAction()` + `canOpenLayoutEditor()` for `livewire_page` \| `grapesjs` and (`ApiDocLayoutGate` **or** `canView`). |
| Edit / View / List header or row action | ✅ | `EditApiDocTemplate` / `ViewApiDocTemplate` header actions; table `recordActions`. |
| Page registration | ✅ | `shouldRegisterNavigation(): false`; panel discovers `Gz168\ApiDoc\Filament\Pages` (no ServiceProvider change needed). |
| Grapes branch | ✅ (Task 9 defer) | `@if ($this->isGrapesEditor())` → `#api-doc-grapes-root` + `wire:ignore` placeholder — **OK for Task 8**. |
| Feature tests (smoke + save + gate + grapes) | ✅ | `ApiDocTemplateLayoutEditorPageTest` (4 cases). |
| Commits | ✅ | gz168 `1b75319`, parent `25a0d90`. |

**Brief delta (non-blocking):** Brief wording `saveLayout`: “gate check **or abort 403**” — implementation uses **soft deny** (notification + return), matching Task 7 `EditApiDocTemplate::saveLayout`. Mount correctly **403**s when `canView` fails.

**Tests (verified 2026-09-18):**

```text
php artisan test --compact tests/Feature/ApiDoc/ApiDocTemplateLayoutEditorPageTest.php
# 4 passed, 13 assertions
```

Matches report.

---

## Strengths

- **Reuses Task 7 blade and semantics** — same sortable UI, gate/visual flags, and persistence path; standalone page passes explicit `$canWrite` / `$visualEnabled` so behavior does not depend on Edit form `data`.
- **Shared entry point** — `openLayoutEditorAction()` centralizes URL + visibility for list, edit, and view surfaces.
- **View-capable, layout-read-only users** — action visible when `canView` without layout gate; mutators no-op and save does not persist (covered by `save_layout_without_gate_fails_soft`).
- **Full-width editor** — `maxContentWidth = Width::Full` appropriate for two-column layout.
- **Grapes hook** — conditional branch and stable `#api-doc-grapes-root` id give Task 9 a clear mount point without shipping half-finished JS.

---

## Issues

### Critical (must fix)

_None._

### Important (non-blocking)

1. **Duplicated Livewire layout logic** — `moveLayoutNode*`, `toggleLayoutNodeVisible`, `syncLayoutTreeNodesFromRecord`, and `saveLayout` mirror `EditApiDocTemplate` (~80 lines). Acceptable for Task 8; a shared trait or small concern would reduce drift risk before Task 9 adds grapes-specific save paths.
2. **`layout_visual_enabled` off — no dedicated page test** — Tab driver has `save_layout_requires_visual_enabled`; page relies on same notifications and `canMutateLayoutTree()` but no feature test asserts save warning + unchanged tree on the standalone page.
3. **Gate test setup** — `save_layout_without_gate_fails_soft` runs `migrate --path` for RolePermission tables; report documents package migration registration gap. Works in CI/local but brittle if paths change.

### Minor (nice to have)

1. **Action visibility untested** — No assert that「打开布局编排」is hidden when `layout_editor === filament_tab` (or other drivers).
2. **Mount 403 untested** — No feature test for user without view permission on `mount`.
3. **Grapes placeholder only** — No livewire_page vs grapesjs mutual exclusion test beyond placeholder HTML (sufficient for Task 8 scope).
4. **Navigation metadata on hidden page** — Icon/group set though nav registration disabled; harmless Filament convention.

---

## Commit hygiene

- gz168: single commit, five files (~334 LOC) — focused on page + resource wiring.
- Parent: submodule bump + one feature test file — appropriate split.

---

## Dual verdict (summary)

| Gate | Verdict |
|------|---------|
| **Part 1 — Spec compliance** | ✅ **Approved** — Standalone layout editor page with mount auth, id/code resolution, Task 7 sortable reuse, preview pane, `LayoutTreeService` save, resource actions for `livewire_page` / `grapesjs`, and four brief-aligned tests; Grapes placeholder explicitly acceptable for Task 8. |
| **Part 2 — Code quality** | ✅ **Approved** with follow-ups — Important: duplicated tab/page Livewire methods; missing visual-off page test; RolePermission migrate-in-test coupling. No critical defects. |

---

## Gate decision

| Gate | Result |
|------|--------|
| Task-scoped spec | **PASS** (Part 1 ✅) |
| Quality (task scope) | **PASS** (Part 2 Approved) |
| Ready to merge (Task 8 `livewire_page` layout editor) | **YES** |

---

## Follow-ups (optional)

- Feature test: `layout_visual_enabled === false` → save warning + unchanged tree on layout editor page.
- Feature test: action hidden when editor is not `livewire_page` / `grapesjs`.
- Extract shared layout-tree Livewire behavior (trait) shared by tab and page before Task 9.
- Task 9: replace grapes placeholder with Vite/Grapes canvas on `#api-doc-grapes-root`.
