# Task 4 Review: LayoutTreeService

**Reviewer:** Task-scoped gate (read-only, re-review after Important fix)  
**Diff reviewed:** `/var/www/dev-laraval/.superpowers/sdd/task-4-review-package.diff` (gz168 `bb70ce2`→`094cade`, parent `941fa9f`→`c50b215`)  
**Brief:** `/var/www/dev-laraval/.superpowers/sdd/task-4-brief.md`  
**Report:** `/var/www/dev-laraval/.superpowers/sdd/task-4-report.md`  
**Prior review:** Important blocked Quality (`saveQuietly` bypass); addressed in fix commits gz168 `094cade`, parent `c50b215`.

## Verdict

| Dimension | Result |
|-----------|--------|
| **Spec** | ✅ |
| **Quality** | **Approved** |

Behavioral brief + global constraints remain met. The Important fix removes the privileged persist path: `LayoutTreeService` uses normal `$template->save()`, model-level `=>` restore runs after sanitize, and gate-aware `trustedLayoutDualWrite` allows authorized tree+page dual-write without defeating the visual page lock for page-only tamper.

## Re-review checklist (Important fix)

| Check | Status | Evidence |
|-------|--------|----------|
| `saveQuietly` gone from service persist path | ✅ | `LayoutTreeService.php` L32: `$template->save()` only; no `saveQuietly` in gz168 ApiDoc layout code |
| Model restores `=&gt;` → `=>` on `body_parts.page` | ✅ | `ApiDocTemplate.php` L83–88 after `sanitizeBodyParts` |
| Gated layout_tree dual-write (page lock exemption) | ✅ | `trustedLayoutDualWrite` when `layout_tree` dirty **and** `ApiDocLayoutGate::allows(auth()->user())`; page revert skipped only then (L118–130) |
| Tests cover literal `=>` after persist | ✅ | `save_dual_writes_tree_and_page`: `assertStringContainsString('=>')` + `assertStringNotContainsString('=&gt;')` after `refresh()` |
| Layout gate still enforced on model save | ✅ | `unauthorized_layout_tree_mutation_is_restored`: unauthenticated `layout_tree` change reverted on `save()` |

**Tests (re-run 2026-09-18):** `LayoutTreeServiceTest` + `ApiDocLayoutGateTest` + `PageSkeletonWriterTest` — **8 passed, 13 assertions**.

## Global constraints

| Constraint | Status | Evidence |
|------------|--------|----------|
| Dual-write `layout_tree` + `body_parts.page` | ✅ | Service assigns both; test asserts tree + `api_doc_part('header'` |
| Persisted page keeps literal `=>` (not `=&gt;`) | ✅ | Model + service restore; feature test after `refresh()` |
| Cache flush after save | ✅ | `ApiDocCacheManager::flush()` after persist |
| `resolveEffectivePage`: null when visual disabled | ✅ | Early return; brief test |
| Fail-soft Writer when enabled and page empty | ✅ | Non-empty page → return; else tree validate+Writer; else Defaults+Writer; no persist |

## Spec compliance (brief)

| Requirement | Status | Evidence |
|-------------|--------|----------|
| `LayoutTreeService::save` + `resolveEffectivePage` interfaces | ✅ | `gz168/ApiDoc/src/Layout/LayoutTreeService.php` |
| validate → set tree → set page from Writer → persist → flush | ✅ | Order matches; `$template->save()`; flush present |
| Brief uses model `save()` | ✅ | Fix commit; no quiet save on service path |
| Disabled visual → `resolveEffectivePage` null | ✅ | Test + implementation |
| Tests per brief (+ `=>` assertion) | ✅ | Parent `LayoutTreeServiceTest.php` (+ gate restore test from fix) |
| Commits | ✅ | feat `7046d20` / `db163f0`; fix `094cade` / `c50b215` |

## Quality

**Strengths**

- Clear, small service: validate → Writer → dual-assign → **model** `save()` → flush.
- Model hooks now own defense-in-depth: sanitize → `=>` restore → layout gate → conditional page lock.
- Trusted dual-write is narrowly scoped (dirty `layout_tree` + gate allows), preserving Filament page-tamper resistance when tree is not part of the save.
- `resolveEffectivePage` correctly returns `null` when visual off; fail-soft regenerate does not persist.
- Feature tests lock dual-write, `=>` persistence through full hook stack, and unauthorized layout field restore.

### Critical

- None.

### Important (prior — **resolved**)

1. **`saveQuietly()` bypasses model gates** — **Fixed.** Service uses `$template->save()`. Model adds post-sanitize `=>` restore and `trustedLayoutDualWrite` page-lock exemption. Unauthorized `layout_tree` mutations still restored (tested).

### Minor (non-blocking)

1. **Resolve fallbacks untested** — no coverage for enabled + empty page + tree / defaults Writer paths (report acknowledged).
2. **Redundant `str_replace` in service** — defense in depth alongside model restore; acceptable.
3. **Invalid stored tree** — enabled + empty page + corrupt `layout_tree` → `validate()` throws (not soft). Acceptable for M1.

## Commit hygiene

- gz168: feat + focused fix on `LayoutTreeService.php` and `ApiDocTemplate.php` — good.
- Parent: submodule pointer to `094cade` + feature test (incl. fix-era cases) — good.
- Test helper `actingAsLayoutAdmin()` uses `saveQuietly()` on **User** only (unrelated to template persist path).

## Gate decision

| Gate | Result |
|------|--------|
| Task-scoped spec | **PASS** (Spec ✅) |
| Quality (task scope) | **PASS** (Approved) |
| Ready to merge (Task 4) | **YES** |

## Follow-ups (optional, out of Task 4 scope)

- Add `resolveEffectivePage` tests for tree/defaults fail-soft branches.
- Longer-term: harden `ApiDocHtmlSanitizer` for Blade-bearing `page` so restores are unnecessary.
