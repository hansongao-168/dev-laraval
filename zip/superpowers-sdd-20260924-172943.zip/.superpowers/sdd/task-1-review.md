# Task 1 Review: ApiDoc layout visual M1 (columns / gate)

**Reviewer:** Subagent (read-only)  
**Diff reviewed:** `task-1-review-package.diff` (gz168 `f2c3926..e74b561`, parent `7064032..bded1a1`)  
**Brief:** `task-1-brief.md` | **Report:** `task-1-report.md` (unverified except via diff)

## Verdicts

| Dimension | Result |
| --- | --- |
| **Spec compliance** | ✅ Pass |
| **Task quality** | **Approved** (non-blocking follow-ups below) |

---

## Spec compliance

Task 1 deliverables match the brief and global constraints:

- **Migration:** `layout_visual_enabled` (bool, default false), `layout_editor` (string 32, default `filament_tab`), `layout_tree` (json nullable), after `js_text`.
- **`ApiDocLayoutEditor`:** three cases with correct value strings and labels.
- **`ApiDocLayoutParts::KEYS`:** seven leaf keys; `label()` helper present (brief only required KEYS list).
- **`ApiDocPermission::TemplatesLayout`:** slug `api-doc.templates.layout`, label「编排前台模板布局」; seeder row with `ApiDocTemplateResource` / `layout`; admin sync unchanged.
- **`ApiDocLayoutGate::allows(?Authenticatable)`:** null → false; requires `Authorizable`; uses `hasPermission` with the layout slug (via enum value).
- **Model:** fillable + casts for layout columns; `saving` restores layout fields when gate denies; when `layout_visual_enabled` is true, restores `body_parts.page` from original via page-only dirty check (not whole-`body_parts` blunt restore).
- **Factory defaults** match brief.
- **Scope:** no frozen-leaf / Filament / importer work.
- **Security invariants:** no `.env` exposure; no weakening of protected super-admin semantics (gate is additive permission check only).

Parent commit is tests-only; gz168 submodule pointer not bumped (split-repo note in report)—outside Task 1 file list but worth tracking for CI.

---

## Task quality

### Strengths

- Model guards follow the existing `js_text` gate placement and ordering (sanitize → JS restore → layout restore → page lock).
- Page tamper resistance is correctly scoped to the `page` slice only (`isBodyPartsPageDirty`).
- Permission slug, enum, migration, and factory align with the design spec.
- Gate unit test matches the brief verbatim; super-admin allow path is consistent with `HasRoles::hasPermission` short-circuit (no `roles` table query).

### Findings

#### Important (non-blocking for Task 1)

1. **`ApiDocLayoutGate` vs module convention**  
   `ApiDocAuthorization::canApiDoc()` is a single `instanceof Authorizable && hasPermission(...)` check. `ApiDocLayoutGate` adds a `Schema::hasTable('roles')` fail-closed branch (only on the non–super-admin/non-admin path) and a redundant super-admin/admin pre-call to `hasPermission` (already short-circuited inside `HasRoles`). Behavior is safe in production and fixes host tests where role schema is absent, but it is the only gate in the repo with this pattern—document or converge in a later hygiene pass.

2. **Tests cover gate happy/deny only for super-admin / unprivileged user**  
   No test for a user granted `api-doc.templates.layout`, and no model tests for layout-field restore or page lock (report defers to later M1 tasks). Acceptable for Task 1 brief scope; increases regression risk until follow-up tasks land.

3. **Denied-user test may not exercise `hasPermission()`**  
   With no `roles` table in host migrations, the deny case likely returns false from `Schema::hasTable('roles')` rather than from an empty permission lookup. The test still matches the brief; it is weaker once role migrations are loaded in the host test DB.

#### Minor

4. **Parent submodule SHA not updated** — clones/CI on parent only need an explicit gz168 checkout or a follow-up pointer bump.

5. **`layout_editor` factory default** uses string `'filament_tab'` instead of `ApiDocLayoutEditor::FilamentTab->value` (equivalent; style only).

6. **Migration** omits `declare(strict_types=1)` (consistent with many Laravel migrations; not required by brief).

---

## Checklist vs implementer claims

| Claim | Assessment |
| --- | --- |
| RED → GREEN on `ApiDocLayoutGateTest` | Plausible from diff + `HasRoles` super-admin short-circuit; not re-run in review |
| Pint clean | Not verified (read-only) |
| Model save guards satisfy global constraints | ✅ Confirmed in diff |
| Submodule pointer not bumped | ✅ Confirmed (parent diff is test-only) |

---

## Recommendation

**Merge Task 1 as spec-complete.** Track Important items 1–3 in subsequent M1 tasks (model/feature tests, optional gate simplification, submodule pointer when integrating gz168).
