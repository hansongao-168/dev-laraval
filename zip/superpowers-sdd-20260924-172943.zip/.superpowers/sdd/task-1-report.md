# Task 1 Report: Migration, enum, gate, model columns (ApiDoc layout visual M1)

## Status

**COMPLETE** — RED → GREEN on `ApiDocLayoutGateTest`; Pint clean; commits on `feat/apidoc-display-modes`.

## Commits

| Repo | SHA | Subject |
| --- | --- | --- |
| `gz168` | `e74b561` | feat(api-doc): add layout visual columns and permission gate |
| parent | `bded1a1` | test(api-doc): add layout permission gate unit tests |

Parent commit includes **tests only** (per split-repo instructions); `gz168` submodule pointer on parent was **not** bumped.

## What was delivered

### Migration `2026_09_18_000015_add_layout_visual_to_api_doc_templates_table.php`

- `layout_visual_enabled` boolean, default `false`
- `layout_editor` string(32), default `filament_tab`
- `layout_tree` json nullable  
- Columns placed after `js_text` (matches existing template column ordering).

### Enums & support

- **`ApiDocLayoutEditor`**: `FilamentTab` / `LivewirePage` / `GrapesJs` → `filament_tab` / `livewire_page` / `grapesjs` + Chinese labels.
- **`ApiDocPermission::TemplatesLayout`**: slug `api-doc.templates.layout`, label「编排前台模板布局」.
- **`ApiDocLayoutParts::KEYS`**: seven leaf keys (`header`, `nav`, `intro_section`, `api_section`, `carriers_section`, `decisions_section`, `note`) + `label()` helper.
- **`ApiDocLayoutGate::allows(?Authenticatable)`**: requires `Authorizable`; uses `hasPermission('api-doc.templates.layout')` with super-admin/admin short-circuit via existing `HasRoles` behavior.

### Seeder & factory

- **`ApiDocPermissionSeeder`**: new permission row for `ApiDocTemplateResource` / `layout`; admin role still `sync(Permission::pluck('id'))`.
- **`ApiDocTemplateFactory`**: `layout_visual_enabled => false`, `layout_editor => filament_tab`, `layout_tree => null`.

### Model `ApiDocTemplate`

- Fillable + casts for the three layout columns (`layout_tree` as array).
- **`saving` guards** (after sanitizer / js restore):
  1. Without layout gate: if any of `layout_visual_enabled`, `layout_editor`, `layout_tree` dirty → restore from original on update, or defaults on create (`false`, `filament_tab`, `null`).
  2. When `layout_visual_enabled` true and `body_parts` page content changed → merge restored `page` from original `body_parts` (via `isBodyPartsPageDirty()` helper comparing page slice only).

## Tests

```text
php artisan test --compact tests/Unit/ApiDoc/ApiDocLayoutGateTest.php
# 2 passed
```

Test file matches task brief verbatim (`LazilyRefreshDatabase`, super admin allowed, non-privileged user denied).

## Self-review

### Strengths

- Gate slug and enum case match design spec exactly.
- Model save guards mirror `js_text` gate pattern and satisfy global constraints from the task.
- Minimal scope: no LayoutTreeService, Filament, or importer changes.

### Concerns / follow-ups

1. **`ApiDocLayoutGate` and missing `roles` table**  
   Host test DB has no Spatie/gz168 permission migrations loaded (`RolePermissionServiceProvider` intentionally does not auto-load). Non–super-admin `hasPermission()` would SQL-error. Gate **fail-closes** with `Schema::hasTable('roles')` before role lookup for non-admin/non-super-admin users. Production hosts with role schema are unaffected; consider aligning host test migrations with `AdminModuleVisibilityForSuperAdminTest` expectations long-term.

2. **Submodule pointer**  
   Parent repo does not record new `gz168` SHA; CI/clones need `git submodule update` + gz168 branch checkout or a follow-up parent commit bumping `gz168`.

3. **`api_doc_templates` base table**  
   Layout migration assumes table + `js_text` column exist (from prior template catalog work). Not validated in this task’s tests.

4. **No model tests yet** for page lock / layout field restore — planned in later M1 tasks (Filament / feature tests).

## Files touched

**Created (gz168):**

- `ApiDoc/database/migrations/2026_09_18_000015_add_layout_visual_to_api_doc_templates_table.php`
- `ApiDoc/src/Enums/ApiDocLayoutEditor.php`
- `ApiDoc/src/Support/ApiDocLayoutParts.php`
- `ApiDoc/src/Support/ApiDocLayoutGate.php`

**Modified (gz168):**

- `ApiDoc/src/Enums/ApiDocPermission.php`
- `ApiDoc/database/seeders/ApiDocPermissionSeeder.php`
- `ApiDoc/src/Models/ApiDocTemplate.php`
- `ApiDoc/database/factories/ApiDocTemplateFactory.php`

**Created (parent):**

- `tests/Unit/ApiDoc/ApiDocLayoutGateTest.php`
