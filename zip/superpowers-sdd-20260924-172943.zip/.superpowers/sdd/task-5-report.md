# Task 5 Report: Snapshot export/import + SkinCopier layout fields

**Date:** 2026-09-18  
**Branch:** `feat/apidoc-display-modes` (gz168 + parent)  
**Status:** Complete

## Summary

Snapshot export/import now carries `layout_visual_enabled`, `layout_editor`, and `layout_tree`. Import validates the editor via `ApiDocLayoutEditor::tryFrom` and the tree via `LayoutTreeValidator` when non-null. When visual mode is enabled and a tree is present, import re-runs `LayoutTreeService::save` so `body_parts.page` cannot drift from a stale snapshot page. SkinCopier ensures layout column defaults on create/copy.

## TDD Flow

| Phase | Result |
| --- | --- |
| RED | Export missing layout keys; import did not apply/rewrite page |
| GREEN | 2 passed, 12 assertions |
| Related | Snapshot templates/js + SkinCopier — 11 passed, 29 assertions |
| Pint | Passed (`vendor/bin/pint --dirty --format agent`) |

## Files Created / Updated

| Path | Role |
| --- | --- |
| `gz168/ApiDoc/src/Services/ApiDocExporter.php` | Export three layout columns |
| `gz168/ApiDoc/src/Services/ApiDocImporter.php` | Validate editor/tree; Writer dual-write when enabled |
| `gz168/ApiDoc/src/Services/ApiDocTemplateSkinCopier.php` | Default `layout_editor` / `layout_visual_enabled` if missing |
| `tests/Feature/ApiDoc/ApiDocSnapshotLayoutVisualTest.php` | Reject bad editor + successful round-trip/page rewrite |

## Implementation Notes

### Exporter

Adds `layout_visual_enabled` (bool), `layout_editor` (default `filament_tab`), `layout_tree` (nullable array) to each template row.

### Importer

1. Validate `layout_editor` with `ApiDocLayoutEditor::tryFrom` → `RuntimeException` on failure (runs even on dry-run).
2. When `layout_tree` is non-null, validate via `LayoutTreeValidator` (wrap `InvalidArgumentException` as `RuntimeException`).
3. Fill model layout fields.
4. If `layout_visual_enabled` and tree present: clear `layout_tree` on the first save so the subsequent `LayoutTreeService::save` marks the tree dirty — required for the model’s trusted dual-write / page-lock path to accept the regenerated `page`.

### SkinCopier

If `layout_editor` is empty → `filament_tab`. If `layout_visual_enabled` is null → `false`. Leaves an existing `layout_tree` untouched.

## Test Cases

1. **export_and_import_round_trips_layout_fields** — export includes enabled + `livewire_page`; import with `layout_editor=nope` throws `RuntimeException`.
2. **import_round_trips_valid_layout_and_rewrites_page** — valid editor/tree round-trip; drifted snapshot `page` regenerated with `api_doc_part('header'` and literal `=>`.

Tests act as a layout-capable super admin so model layout-gate hooks allow writes (same pattern as `LayoutTreeServiceTest`).

## Commits

| Repo | SHA | Message |
| --- | --- | --- |
| gz168 | `bcaaeb9` | feat(api-doc): snapshot layout visual fields |
| parent | `8b39b61` | feat(api-doc): snapshot layout visual fields |

Parent commit includes submodule pointer update + feature test. Report lives under `.superpowers/sdd/` (gitignored).

## Verification Command

```bash
php artisan test --compact tests/Feature/ApiDoc/ApiDocSnapshotLayoutVisualTest.php
```

**Evidence (2026-09-18):** 2 passed, 12 assertions. Related suite (templates/js/SkinCopier + this file): 11 passed, 29 assertions.

## Concerns / Follow-ups

- Import layout writes require an authenticated user allowed by `ApiDocLayoutGate` (super admin / layout permission). Without it, model hooks restore layout fields — same invariant as Filament edits. Snapshot UI already requires import permission; operators importing layout-enabled skins should also have layout permission (or be super admin).
- Old snapshots without layout keys import as visual-off / `filament_tab` / null tree.
- SkinCopier does not copy layout tree from a source skin (create defaults only); intentional for M1.
