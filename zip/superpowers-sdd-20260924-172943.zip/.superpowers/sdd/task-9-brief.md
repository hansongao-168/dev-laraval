### Task 9: Driver `grapesjs`

**Files:**
- Modify: `package.json` — add `grapesjs` dependency
- Modify: `vite.config.js` — add input `gz168/ApiDoc/resources/js/layout/grapes-editor.js` (or `resources/js/api-doc-layout-grapes.js` symlink path under app resources that imports package file)
- Create: `gz168/ApiDoc/resources/js/layout/grapes-editor.js`
- Modify: layout editor Blade — grapes canvas root + Alpine/Livewire hooks
- Test: extend `ApiDocTemplateLayoutEditorPageTest` — page with `layout_editor=grapesjs` loads 200 and contains `#api-doc-grapes-root`; save still goes through Service with JSON tree (simulate `call('saveLayout', $tree)` without needing browser Grapes)

**Grapes rules (enforce in JS init):**
- Only register 7 blocks matching parts; `editor.BlockManager` add each once.
- `storageManager: false`; on load, drop blocks from `layoutTree` order with `visible` → if false set style `display:none` or trait checkbox.
- On 「应用到树」, read canvas component order → emit Livewire `layoutTreeNodes`; do not allow `append` of unknown blocks (listen `block:drag:stop` and remove illegal).
- Side panel: when component selected, Livewire `selectedPart` → server renders read-only HTML via `ApiDocTemplateViewResolver` or raw `body_parts[part]` into `<iframe srcdoc>` (sanitized).

- [ ] **Step 1: `npm install grapesjs --save-dev` (or dependencies) + vite entry; `npm run build` must succeed**

- [ ] **Step 2: PHPUnit smoke without depending on JS runtime**

- [ ] **Step 3: Commit**

```bash
git commit -m "feat(api-doc): grapesjs layout editor shell"
```

---

