# Final Review: ApiDoc Front Templates (Skin)

**Feature:** Wire `api_doc_display_modes.template_key` to config-registered front skins (V1: `classic` only)  
**Diff package:** `.superpowers/sdd/final-front-templates-review-package.diff`  
**Parent commits (templates plan):** `e77578a` … `c9c8478`  
**gz168 commits:** `1c3030b` → `53449b1`  
**Spec:** `docs/dev-laraval/superpowers/specs/2026-09-15-apidoc-front-templates-design.md`  
**Plan:** `docs/dev-laraval/superpowers/plans/2026-09-15-apidoc-front-templates.md`  
**Verification (Task 6 report):** `php artisan test --compact tests/Unit/ApiDoc tests/Feature/ApiDoc` → **51/51 pass** (not re-run in this review)

---

## Overall verdict

**Approve with nits**

All six plan tasks are delivered against the design spec: config catalog + resolver, seeder/model validation, Filament Select, `views_prefix` front wiring, template-scoped cache keys (render + ui) with flush/legacy coverage, and snapshot `display_modes` export/import with fail-closed illegal keys. Remaining items are deferred test/polish nits from task reviews; none block merge.

---

## Plan / spec alignment

| Spec / plan item | Status | Notes |
| --- | --- | --- |
| `config` `templates.default` + `catalog.classic` (`label`, `views_prefix`, `assets`) | ✅ | Matches §3.1; assets reserved, not required to drive layout in V1 |
| `ApiDocResolvedTemplate` + `ApiDocTemplateResolver` | ✅ | `resolve` / `defaultKey` / `isRegistered` / `options` / `view()` |
| null / empty → default; unknown → default + `Log::warning` | ✅ | Implementation complete; empty-string unit path untested (nit) |
| Empty catalog / missing default / missing `views_prefix` → fail-fast | ✅ | Covered for missing default; other throws present in code |
| Seeder + factory write `classic` | ✅ | Five modes; zero null |
| Model: empty → null; non-null must be registered | ✅ | `saving` guard |
| Filament Select + table column; illegal key blocked | ✅ | `Rule::in` + Livewire reject test; permissions unchanged |
| Write path flushes ApiDoc cache | ✅ | Create/Edit `syncDefaultAndFlush()` → `flushApiDocCache()` |
| `ApiDocPage` uses `views_prefix`; missing views fail-fast | ✅ | Tested with fake `broken` catalog entry |
| Cache `render:{mode}:{template}[:html]` + `ui:…` | ✅ | Mockery key assertions; isolation via fake `alt` |
| Flush new + legacy keys (incl. DB mode codes × catalog) | ✅ | Render `:html` pair asserted; `ui:` flush optional gap |
| Snapshot `display_modes` with `template_key`; reject bad key whole-import | ✅ | Validate before writes; `ensureInvariant()` after |
| No second skin UI / no `?template=` / no DB template table / no view move | ✅ | Out of scope respected |
| Front regression | ✅ | Classic 200 + existing front suite in Task 4/6 gate |

Unrelated parent files in the package’s “parent tests” section (`ApiDocHelperTest`, `ApiDocIntroShapeTest`, `PathHelpersTest`) are outside this feature’s judgment.

---

## Strengths

- Clean dependency direction: Filament / Livewire / Renderer → `ApiDocTemplateResolver` → config catalog; no scattered skin `if`s.
- Runtime vs persistence split is correct: unknown keys soft-fallback at resolve time; Filament + model + import reject illegal keys so they do not land.
- Cache isolation is proven with a fake second catalog entry pointing at the same views (matches Spec §5.2 guidance without building a second UI).
- Missing registered views fail closed with an explicit `RuntimeException`, distinct from unknown-key fallback (Spec §6).
- Snapshot section is ordered (`sort`, `code`), typed, and fail-closed before mutation; dry-run still validates without writing.
- Task-review Important gaps (missing-view test, `ui:` key shape, flush coverage for render keys) were closed before this final gate.
- Constructor DI for `ApiDocTemplateResolver` on `ApiDocRenderer` + singleton registration is tidy and testable.

---

## Issues

### Critical (Must Fix)

_None._

### Important (Should Fix)

_None._

No missing planned functionality, architectural holes, or production-blocking defects identified in the templates package. Known importer flush-before-validate behavior is optional backlog (see Minor), not a templates-specific regression that warrants holding the merge.

### Minor (Nice to Have)

1. **Log warning context not asserted**  
   - File: `tests/Unit/ApiDoc/ApiDocTemplateResolverTest.php` (`resolve_unknown_key_falls_back_and_logs_warning`)  
   - Issue: Asserts `warning` once only; does not lock `template_key` / `mode_code` / `fallback` context.  
   - Why: Supportability of dirty historical keys relies on that context.  
   - Fix: `Log::shouldHaveReceived('warning')->withArgs(...)` (or equivalent).

2. **Empty-string `template_key` → null untested**  
   - File: `ApiDocDisplayMode` `saving` + tests  
   - Issue: Model normalizes `''` → `null`; no dedicated assertion. Resolver trim-empty → default is also untested as its own case (null covers similar path).  
   - Fix: One model test assigning `''` and asserting `null` after save.

3. **Flush test optional gap for `ui:` keys**  
   - File: `tests/Feature/ApiDoc/ApiDocFrontTemplateTest.php` (`flush_forgets_legacy_and_template_scoped_render_html_keys`)  
   - Issue: Asserts legacy + template-scoped `render:…:html` only; flush also forgets `ui:` legacy/template variants.  
   - Fix: Put/assert the `ui:` pair the same way (optional hardening).

4. **Import flush-before-validate on failed import**  
   - File: `ApiDocImporter` transaction (flush then `display_modes` validation)  
   - Issue: Non–dry-run invalid snapshot throws after cache flush; DB rolls back, cache stays cold. Matches plan order; broader importer pattern.  
   - Fix (optional): Validate `display_modes` template keys before flush, or re-warm after failed import. Defer unless ops care about transient empty cache.

5. **Cosmetic / polish**  
   - Stray blank line in importer `display_modes` block.  
   - Filament table null/empty state shows `defaultKey()` string (`classic`) rather than catalog label `经典` (matches plan snippet).  
   - Filament reject test does not re-assert DB unchanged after form errors (safe with Select + `Rule::in`).  
   - Cached render payload includes `'template' => $skin->key` while Spec §5.1 says aggregation payload is skin-independent for locale layout — metadata only; content isolation remains via cache key. Harmless for V1.

---

## Task-review backlog triage

| Item | Severity here | Triage |
| --- | --- | --- |
| Log warning context not asserted | Minor #1 | **Defer** |
| Empty-string → null untested | Minor #2 | **Defer** |
| Flush test optional gap for `ui:` keys | Minor #3 | **Defer** |
| Import flush-before-validate on failed import | Minor #4 | **Defer** (optional) |

---

## Recommendations

- Ship V1 as-is; optionally fold Minors #1–#3 into a small follow-up test PR.
- When adding a second catalog skin, prefer real view prefixes + assets consumption from `$template`; keep isolation tests with a second registered key.
- If snapshot consumers need schema signaling, consider bumping export `version` when `display_modes` becomes required (not required for V1; key is optional on import).

---

## Assessment

**Ready to merge?** **Approve with nits**

**Reasoning:** Spec and plan are fully implemented for V1 classic skin wiring, admin Select, cache isolation, and snapshot round-trip with fail-closed illegal keys. Prior task Important findings were addressed. Remaining gaps are non-blocking test depth and optional importer cache ordering polish.
