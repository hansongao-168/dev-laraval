### Task 1: Migration, enum, gate, model columns

**Files:**
- Create: `gz168/ApiDoc/database/migrations/2026_09_18_000015_add_layout_visual_to_api_doc_templates_table.php`
- Create: `gz168/ApiDoc/src/Enums/ApiDocLayoutEditor.php`
- Create: `gz168/ApiDoc/src/Support/ApiDocLayoutParts.php`
- Create: `gz168/ApiDoc/src/Support/ApiDocLayoutGate.php`
- Modify: `gz168/ApiDoc/src/Enums/ApiDocPermission.php`
- Modify: `gz168/ApiDoc/database/seeders/ApiDocPermissionSeeder.php`
- Modify: `gz168/ApiDoc/src/Models/ApiDocTemplate.php`
- Modify: `gz168/ApiDoc/database/factories/ApiDocTemplateFactory.php`
- Test: `tests/Unit/ApiDoc/ApiDocLayoutGateTest.php`

**Interfaces:**
- Produces: `ApiDocLayoutEditor` cases `FilamentTab`, `LivewirePage`, `GrapesJs` with `value` strings `filament_tab` / `livewire_page` / `grapesjs`; `ApiDocLayoutParts::KEYS` list of 7 strings; `ApiDocLayoutGate::allows(?Authenticatable $user): bool`; model attributes `layout_visual_enabled`, `layout_editor`, `layout_tree`.

- [ ] **Step 1: Write failing gate test**

```php
<?php

declare(strict_types=1);

namespace Tests\Unit\ApiDoc;

use App\Models\User;
use Gz168\ApiDoc\Support\ApiDocLayoutGate;
use Illuminate\Foundation\Testing\LazilyRefreshDatabase;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class ApiDocLayoutGateTest extends TestCase
{
    use LazilyRefreshDatabase;

    #[Test]
    public function super_admin_is_allowed(): void
    {
        $user = User::factory()->make();
        $user->forceFill(['is_super_admin' => true, 'is_protected' => false])->saveQuietly();
        $this->assertTrue(ApiDocLayoutGate::allows($user));
    }

    #[Test]
    public function user_without_permission_is_denied(): void
    {
        $user = User::factory()->make();
        $user->forceFill(['is_super_admin' => false, 'is_protected' => false])->saveQuietly();
        $this->assertFalse(ApiDocLayoutGate::allows($user));
    }
}
```

- [ ] **Step 2: Run test — expect FAIL** (class missing)

Run: `php artisan test --compact tests/Unit/ApiDoc/ApiDocLayoutGateTest.php`

- [ ] **Step 3: Implement migration + support classes + model**

Migration columns:
- `layout_visual_enabled` boolean default false
- `layout_editor` string(32) default `filament_tab`
- `layout_tree` json nullable

`ApiDocPermission::TemplatesLayout = 'api-doc.templates.layout'` with Chinese label「编排前台模板布局」.

`ApiDocLayoutGate::allows` → user implements `Authorizable` and `hasPermission('api-doc.templates.layout')`.

Model: add fillable + casts (`layout_visual_enabled` bool, `layout_tree` array). In `saving`: if `$template->layout_visual_enabled` and `body_parts.page` is dirty, restore `body_parts['page']` from original (merge into body_parts array). Also: if not `ApiDocLayoutGate::allows(auth()->user())` and any of `layout_visual_enabled` / `layout_editor` / `layout_tree` dirty → restore those three from original (create: defaults).

Factory defaults: `layout_visual_enabled => false`, `layout_editor => filament_tab`, `layout_tree => null`.

Seeder: append permission row; admin role sync stays as-is (pluck all).

- [ ] **Step 4: Run migration in test env + gate tests PASS**

Run: `php artisan migrate --no-interaction` (or rely on RefreshDatabase) then `php artisan test --compact tests/Unit/ApiDoc/ApiDocLayoutGateTest.php`

- [ ] **Step 5: Commit**

```bash
git add gz168/ApiDoc/database/migrations/2026_09_18_000015_add_layout_visual_to_api_doc_templates_table.php \
  gz168/ApiDoc/src/Enums/ApiDocLayoutEditor.php \
  gz168/ApiDoc/src/Enums/ApiDocPermission.php \
  gz168/ApiDoc/src/Support/ApiDocLayoutParts.php \
  gz168/ApiDoc/src/Support/ApiDocLayoutGate.php \
  gz168/ApiDoc/database/seeders/ApiDocPermissionSeeder.php \
  gz168/ApiDoc/src/Models/ApiDocTemplate.php \
  gz168/ApiDoc/database/factories/ApiDocTemplateFactory.php \
  tests/Unit/ApiDoc/ApiDocLayoutGateTest.php
git commit -m "feat(api-doc): add layout visual columns and permission gate"
```

---

