### Task 10: Pint, suite slice, docs status line

**Files:**
- Touch only if status headers needed on spec (`状态：实现中` optional — skip unless user asked)
- Run pint + targeted tests

- [ ] **Step 1: `vendor/bin/pint --dirty --format agent`**

- [ ] **Step 2: Run**

```bash
php artisan test --compact \
  tests/Unit/ApiDoc/ApiDocLayoutGateTest.php \
  tests/Unit/ApiDoc/LayoutTreeValidatorTest.php \
  tests/Unit/ApiDoc/PageSkeletonWriterTest.php \
  tests/Feature/ApiDoc/LayoutTreeServiceTest.php \
  tests/Feature/ApiDoc/ApiDocSnapshotLayoutVisualTest.php \
  tests/Feature/ApiDoc/ApiDocTemplateLayoutLockTest.php \
  tests/Feature/ApiDoc/ApiDocTemplateLayoutRenderTest.php \
  tests/Feature/ApiDoc/ApiDocTemplateLayoutTabTest.php \
  tests/Feature/ApiDoc/ApiDocTemplateLayoutEditorPageTest.php
```

Expected: all PASS.

- [ ] **Step 3: Ask user whether to run full `php artisan test --compact`**

- [ ] **Step 4: Final commit if pint changed files**

```bash
git commit -m "chore(api-doc): pint layout visual M1"
```

---

## Spec coverage checklist (self-review)

| Spec item | Task |
| --- | --- |
| Columns + defaults | 1 |
| Permission + gate | 1 |
| Tree schema / validator / defaults | 2 |
| PageSkeletonWriter + sections slot | 3 |
| Dual-write service + resolveEffectivePage | 4 |
| Snapshot + import validation | 5 |
| Page lock + Filament fields + runtime | 6 |
| filament_tab | 7 |
| livewire_page | 8 |
| grapesjs + read-only preview | 9 |
| Test matrix / pint | 10 |

No TBD placeholders. Editor enum values match spec. Writer sections-slot rule matches §3.1.
