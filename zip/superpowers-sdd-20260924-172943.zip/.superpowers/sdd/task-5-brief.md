### Task 5: Snapshot export/import + SkinCopier fields

**Files:**
- Modify: `gz168/ApiDoc/src/Services/ApiDocExporter.php`
- Modify: `gz168/ApiDoc/src/Services/ApiDocImporter.php`
- Modify: `gz168/ApiDoc/src/Services/ApiDocTemplateSkinCopier.php` (copy three columns when duplicating DB state if applicable; create flow already fills model — ensure create defaults)
- Test: `tests/Feature/ApiDoc/ApiDocSnapshotLayoutVisualTest.php`

- [ ] **Step 1: Failing test — export includes layout fields; import rejects bad editor; round-trip tree**

```php
#[Test]
public function export_and_import_round_trips_layout_fields(): void
{
    $this->seed(ApiDocDisplayModeSeeder::class);
    $classic = ApiDocTemplate::query()->where('code', 'classic')->firstOrFail();
    $classic->layout_visual_enabled = true;
    $classic->layout_editor = ApiDocLayoutEditor::LivewirePage->value;
    $classic->layout_tree = LayoutTreeDefaults::tree();
    $classic->save();

    $payload = app(ApiDocExporter::class)->exportAll();
    $row = collect($payload['templates'])->firstWhere('code', 'classic');
    $this->assertTrue($row['layout_visual_enabled']);
    $this->assertSame('livewire_page', $row['layout_editor']);

    $payload['templates'][0]['layout_editor'] = 'nope';
    $this->expectException(RuntimeException::class);
    app(ApiDocImporter::class)->import($payload, ApiDocImporter::MODE_OVERWRITE);
}
```

(Second test for successful round-trip with valid editor.)

- [ ] **Step 2: Implement exporter map keys; importer validates editor via `ApiDocLayoutEditor::tryFrom` and tree via Validator when non-null; fill model fields. If `layout_visual_enabled` and tree present, optionally re-run Writer so page matches — **do re-run Writer on import when enabled** so snapshot page cannot drift.**

- [ ] **Step 3: PASS + commit**

```bash
git commit -m "feat(api-doc): snapshot layout visual fields"
```

---

