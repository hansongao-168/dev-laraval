# Task 7 Review: Driver `filament_tab` — Sortable layout Tab

**Reviewer:** Task-scoped gate (read-only)  
**Diff reviewed:** `/var/www/dev-laraval/.superpowers/sdd/task-7-review-package.diff` (gz168 `d332825`→`a3dd2b8`, parent `9773d72`→`0e500f2`)  
**Brief:** `/var/www/dev-laraval/.superpowers/sdd/task-7-brief.md`  
**Report:** `/var/www/dev-laraval/.superpowers/sdd/task-7-report.md`

---

## Global constraints

| Constraint | Status | Evidence |
|------------|--------|----------|
| **7 frozen leaves only** | ✅ | UI lists `layoutTreeNodes` synced from record/defaults; mutators only swap order or flip `visible` (no add/remove). Persist path builds `{ version: 1, nodes: layoutTreeNodes }` → `LayoutTreeValidator` enforces exactly 7 parts from `ApiDocLayoutParts::KEYS` (covered in `LayoutTreeServiceTest` / validator tests). |
| **Save via `LayoutTreeService`** | ✅ | `EditApiDocTemplate::saveLayout` delegates to `app(LayoutTreeService::class)->save($this->getRecord(), $tree)`; dual-write to `layout_tree` + `body_parts.page` stays in service layer. |
| **Gate on write** | ✅ | Blade: `$canWrite = $visualEnabled && ApiDocLayoutGate::allows(...)`, disables ↑↓ / toggle / 保存布局. Livewire: `canMutateLayoutTree()` on moves/toggles; `saveLayout()` danger notification when gate denies. |
| **↑↓ MVP OK** | ✅ | `layout-tree-sortable.blade.php` uses `moveLayoutNodeUp` / `moveLayoutNodeDown`; no SortableJS/drag (deferred per brief/report). |

---

## Spec compliance (brief)

| Requirement | Status | Evidence |
|-------------|--------|----------|
| Tab「布局编排」when `layout_editor === filament_tab` | ✅ | `Tabs::make('layout_editor_tabs')->visible(fn (Get $get): bool => $get('layout_editor') === FilamentTab->value)`, `hiddenOn('create')`. |
| `layout_editor` **live** for mount-by-editor | ✅ | Select gains `->live()` alongside existing gate `disabled`. |
| MVP ↑↓ + visibility → `layoutTreeNodes`; Save → persist | ✅ | Public `$layoutTreeNodes`, move/toggle methods, `saveLayout` + success notification + `refreshFormData(['body_parts','layout_tree'])`. |
| `layout_visual_enabled` required for edits | ✅ | Hint「请先启用可视化布局」when off; `@unless ($visualEnabled)` hides controls; mutators and save short-circuit with warning/no-op. |
| Reusable blade component | ✅ | `gz168-api-doc::filament.components.layout-tree-sortable` (Task 8 reuse noted in report). |
| Feature smoke: reorder updates tree + page order | ✅ | `admin_can_reorder_layout_via_livewire_and_persist_tree_and_page`. |
| Toggle visibility + page string | ✅ | `toggle_visibility_updates_working_nodes_before_save`. |
| Visual-off guard | ✅ | `save_layout_requires_visual_enabled`. |
| Commits | ✅ | gz168 `a3dd2b8`, parent `0e500f2` (submodule + test file). |

**Brief delta (non-blocking):** Brief file list mentions form Hidden `layout_tree` and action name `saveLayoutTree`; implementation uses Livewire state + `saveLayout()` only (no Hidden field). Behavior matches intent (explicit save, not main form dehydrate).

**Tests (verified 2026-09-18):**

```text
php artisan test --compact \
  tests/Feature/ApiDoc/ApiDocTemplateLayoutTabTest.php \
  tests/Feature/ApiDoc/LayoutTreeServiceTest.php
# 6 passed, 25 assertions
```

Task-scoped layout tab file: **3 passed, 19 assertions** (matches report).

---

## Strengths

- **Single persistence path** for layout edits avoids fighting Task 6 page lock / `mutateFormDataBeforeSave` on the main Save action.
- **Shared gate semantics** with Task 6 layout section (toggle/select disabled; write paths re-check `ApiDocLayoutGate`).
- **`syncLayoutTreeNodesFromRecord` after fill/save/layout save** keeps working copy aligned with DB after dual-write.
- **Avoided Livewire `hydrate*` naming collision** (report note) — sensible rename.
- **Focused diff:** one blade, resource tab wiring, edit page methods; tests in parent repo only.

---

## Issues

### Critical (must fix)

_None._

### Important (non-blocking)

1. **Layout gate denial untested in Filament** — `saveLayout` and `canMutateLayoutTree` handle missing permission, but tests only use super-admin with layout capability. Model restore on gate bypass is covered elsewhere (`LayoutTreeServiceTest`); a non-layout admin Livewire test would mirror Task 6 follow-up pattern.
2. **`layout_visual_enabled` live toggle mid-session** — Blade reads `$livewire->data['layout_visual_enabled']`; after toggling visual off without save, UI should disable controls (depends on Filament re-render). No test for flip visual off then attempt save; report acknowledges awkwardness.
3. **Tab visibility vs “user can view template”** — Brief mentions view permission; implementation relies on standard Edit page authorization only (same as other tabs). Acceptable if product treats edit access as view access.

### Minor (nice to have)

1. **Drag-and-drop deferred** — Explicitly OK for M1; blade is structured for Task 8 extension.
2. **No dedicated test that tab UI is hidden when `layout_editor !== filament_tab`** — Livewire reorder tests suffice for core behavior; optional HTTP/schema assert.
3. **Enabling hidden `note` via layout** — Report warns Edit preview fragility; tests wisely use `carriers_section`.

---

## Commit hygiene

- gz168: single commit, three files, ~228 LOC — good scope.
- Parent: submodule bump + one feature test file — good.

---

## Dual verdict (summary)

| Gate | Verdict |
|------|---------|
| **Part 1 — Spec compliance** | ✅ **Approved** — Tab gated on `filament_tab`, MVP ↑↓/visibility, visual enablement, `LayoutTreeService::save`, and three brief-aligned feature tests; global constraints (7 leaves, gate, service save) satisfied. |
| **Part 2 — Code quality** | ✅ **Approved** with follow-ups — Important: optional layout-gate Filament test; mid-session visual toggle UX untested. No critical defects. Hidden `layout_tree` form field omitted in favor of Livewire working copy (documented delta). |

---

## Gate decision

| Gate | Result |
|------|--------|
| Task-scoped spec | **PASS** (Part 1 ✅) |
| Quality (task scope) | **PASS** (Part 2 Approved) |
| Ready to merge (Task 7 `filament_tab` layout editor) | **YES** |

---

## Follow-ups (optional)

- Feature test: admin without `TemplatesLayout` cannot persist via `saveLayout` (notification + unchanged tree).
- Assert layout tab hidden when editor is not `filament_tab` (Filament schema or Livewire).
- Task 8: SortableJS / shared blade drag on top of existing node list.
