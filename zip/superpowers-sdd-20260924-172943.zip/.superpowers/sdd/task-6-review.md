# Task 6 Review: Filament layout fields + page lock + resolveEffectivePage

**Reviewer:** Task-scoped gate (read-only)  
**Diff reviewed:** `/var/www/dev-laraval/.superpowers/sdd/task-6-review-package.diff` (gz168 `bcaaeb9`→`d332825`, parent `8b39b61`→`9773d72`)  
**Brief:** `/var/www/dev-laraval/.superpowers/sdd/task-6-brief.md`  
**Report:** `/var/www/dev-laraval/.superpowers/sdd/task-6-report.md`

---

## Global constraints

| Constraint | Status | Evidence |
|------------|--------|----------|
| Page locked when visual layout enabled | ✅ | Form: `body_parts.page` `disabled` + `dehydrated(false)` when `layout_visual_enabled`; `EditApiDocTemplate::mutateFormDataBeforeSave` restores stored `page`; model `saving` reverts dirty `body_parts.page` when visual on (unless trusted layout-tree dual-write). |
| Front `page` uses `resolveEffectivePage` when visual enabled | ✅ | `ApiDocTemplateViewResolver::render`: for `part === 'page'`, loads template by skin code, calls `LayoutTreeService::resolveEffectivePage`; non-empty string is Blade-rendered **before** empty-override file fallback. Render test clears DB `page`, enables visual, asserts carriers marker absent on `GET /api-doc`. |

---

## Spec compliance (brief)

| Requirement | Status | Evidence |
|-------------|--------|----------|
| Section「布局」: `layout_visual_enabled` Toggle | ✅ | `ApiDocTemplateResource` Section `布局`, `hiddenOn('create')`, gate-disabled, `live()`. |
| Section「布局」: `layout_editor` Select | ✅ | `ApiDocLayoutEditor` cases → options; gate-disabled. |
| Gate on Toggle/Select | ✅ | `disabled(fn (): bool => ! ApiDocLayoutGate::allows(auth()->user()))`. |
| Page textarea lock when visual on | ✅ | Per-key loop: `page` gets `disabled` / `dehydrated` from `Get $get('layout_visual_enabled')`. |
| `mutateFormDataBeforeSave` strip/restore page | ✅ | `EditApiDocTemplate` when visual enabled (form or record). |
| ViewResolver prefers effective page | ✅ | Constructor-injected `LayoutTreeService`; early return on non-empty `resolveEffectivePage`. |
| Lock test: tampering ignored on edit | ✅ | `ApiDocTemplateLayoutLockTest::enabled_visual_ignores_page_tampering_on_edit` (+ field existence asserts). |
| Render test: tree visibility on front | ✅ | `ApiDocTemplateLayoutRenderTest::visual_layout_hides_carriers_when_tree_marks_invisible`. |
| Commits | ✅ | gz168 `d332825`, parent `9773d72` (submodule + tests). |

**Tests (verified 2026-09-18):**

```text
php artisan test --compact \
  tests/Feature/ApiDoc/ApiDocTemplateLayoutLockTest.php \
  tests/Feature/ApiDoc/ApiDocTemplateLayoutRenderTest.php \
  tests/Feature/ApiDoc/ApiDocTemplateRenderTest.php \
  tests/Feature/ApiDoc/LayoutTreeServiceTest.php \
  tests/Feature/ApiDoc/ApiDocTemplateResourceTest.php
# 11 passed, 42 assertions
```

Task-scoped pair: **2 passed, 12 assertions** (matches report).

---

## Strengths

- **Defense in depth** for page lock: Filament dehydration, edit mutation, and model `saving` align with Task 4 trusted dual-write exception (`layout_tree` dirty + layout gate).
- **`live()` on visual toggle** so the page tab disables immediately without save — matches brief UX intent.
- **ViewResolver hook placement** is correct: effective page wins over classic blade when DB `page` is empty but visual + tree are active — the render test would fail on file fallback (`id="transporteurs"`).
- **Render test setup** documents the disable-visual → clear `page` → re-enable pattern needed to bypass model page lock while seeding an empty override.
- **Minimal gz168 surface**: resource form, one edit hook, resolver branch — no unrelated refactors.

---

## Issues

### Critical (must fix)

_None._

### Important (non-blocking)

1. **`ApiDocPage::assertPartAvailable('page')` vs tree regeneration** — Pre-render check still passes when `body_parts.page` is empty if a classic blade file exists; regeneration only happens inside `ViewResolver`. Skins **without** a file fallback and an empty stored `page` could still fail before resolver runs (report follow-up). Teach `assertPartAvailable` about `resolveEffectivePage` or resolve skin from DB when visual is on.
2. **Extra query on every front page render** — `ViewResolver` loads `ApiDocTemplate` by `code` per `page` render. Acceptable for M1; consider passing template/model on `ApiDocResolvedTemplate` later to avoid N+1.
3. **Layout gate UX untested** — Toggle/Select stay visible but disabled without gate; writes are blocked by model hooks, but there is no feature test mirroring `ApiDocSnapshotJsTextTest`-style non-admin Filament save (brief did not require it).

### Minor (nice to have)

1. **`resolveEffectivePage` vs `$skin->bodyParts`** — Resolver consults DB template first; resolved skin cache and DB should stay in sync via existing cache flush on edit; worth a comment if dual sources ever diverge during preview.
2. **Preview path** — `ApiDocTemplatePreviewRenderer` uses the same resolver; no dedicated test that preview HTML reflects hidden tree nodes (front HTTP test covers primary path).
3. **Boost `search-docs` 403** — Report note only; Filament APIs match sibling resources (`js_text` gate pattern).

---

## Commit hygiene

- gz168: single commit, three files, focused feature — good.
- Parent: submodule pointer + two feature test files — good.

---

## Dual verdict (summary)

| Gate | Verdict |
|------|---------|
| **Part 1 — Spec compliance** | ✅ **Approved** — Form fields, page lock (form + edit + model stack), ViewResolver `resolveEffectivePage` hook, and both brief tests delivered; commits match report. |
| **Part 2 — Code quality** | ✅ **Approved** with follow-ups — Important: `assertPartAvailable` gap for file-less skins; per-render DB lookup; optional layout-gate Filament test. No critical defects. |

---

## Gate decision

| Gate | Result |
|------|--------|
| Task-scoped spec | **PASS** (Part 1 ✅) |
| Quality (task scope) | **PASS** (Part 2 Approved) |
| Ready to merge (Task 6 layout Filament + render) | **YES** |

---

## Follow-ups (optional)

- Extend `assertPartAvailable` (or resolver entry) so visual-on + empty `page` + tree does not depend on blade file existence.
- Pass `ApiDocTemplate` (or effective page) on resolved skin DTO to drop redundant query.
- Feature test: non-layout-capable admin cannot persist `layout_visual_enabled` / `layout_editor` via Filament (model restore).
