### Task 8: Driver `livewire_page`

**Files:**
- Create: `gz168/ApiDoc/src/Filament/Pages/ApiDocTemplateLayoutEditorPage.php`
- Create: `gz168/ApiDoc/resources/views/filament/pages/template-layout-editor.blade.php`
- Modify: `ApiDocTemplateResource.php` — header Action「打开布局编排」visible when `layout_editor === livewire_page || grapesjs` and gate allows (or view)
- Register page in `ApiDocServiceProvider` / Filament panel provider discovery
- Test: `tests/Feature/ApiDoc/ApiDocTemplateLayoutEditorPageTest.php`

**Page contract:**
- Route param `template` (record id or code).
- `mount`: authorize Resource view; load template; init nodes from `layout_tree ?? LayoutTreeDefaults::tree()`.
- Left: same ↑↓ / visibility UI as Tab (extract Blade component `layout-tree-sortable`).
- Right: structure preview list of visible parts labels.
- `saveLayout`: gate check or abort 403; require `layout_visual_enabled` or set flash error; call Service.
- Grapes branch: `@if ($template->layout_editor === 'grapesjs')` include grapes root — implemented in Task 9; Task 8 ships livewire_page branch fully.

- [ ] **Step 1: Smoke test** Livewire::test page as admin returns OK; user without gate cannot `saveLayout`.

- [ ] **Step 2: Implement + commit**

```bash
git commit -m "feat(api-doc): livewire_page layout editor"
```

---

