### Task 2: LayoutTreeDefaults + LayoutTreeValidator

**Files:**
- Create: `gz168/ApiDoc/src/Layout/LayoutTreeDefaults.php`
- Create: `gz168/ApiDoc/src/Layout/LayoutTreeValidator.php`
- Test: `tests/Unit/ApiDoc/LayoutTreeValidatorTest.php`

**Interfaces:**
```php
final class LayoutTreeDefaults
{
    /** @return array{version:int,nodes:list<array{id:string,part:string,visible:bool}>} */
    public static function tree(): array;
}

final class LayoutTreeValidator
{
    /**
     * @param  array<string,mixed>  $tree
     * @return array{version:int,nodes:list<array{id:string,part:string,visible:bool}>}
     * @throws \InvalidArgumentException
     */
    public function validate(array $tree): array;
}
```

- [ ] **Step 1: Failing tests**

```php
#[Test]
public function accepts_default_tree(): void
{
    $v = app(LayoutTreeValidator::class)->validate(LayoutTreeDefaults::tree());
    $this->assertSame(1, $v['version']);
    $this->assertCount(7, $v['nodes']);
}

#[Test]
public function rejects_missing_part(): void
{
    $tree = LayoutTreeDefaults::tree();
    array_pop($tree['nodes']);
    $this->expectException(InvalidArgumentException::class);
    app(LayoutTreeValidator::class)->validate($tree);
}

#[Test]
public function rejects_unknown_part(): void
{
    $tree = LayoutTreeDefaults::tree();
    $tree['nodes'][0]['part'] = 'panel';
    $this->expectException(InvalidArgumentException::class);
    app(LayoutTreeValidator::class)->validate($tree);
}
```

- [ ] **Step 2: Run — FAIL**

Run: `php artisan test --compact tests/Unit/ApiDoc/LayoutTreeValidatorTest.php`

- [ ] **Step 3: Implement**

Defaults: exact order from spec; `note.visible = false`; others true; `id === part`.

Validator rules: `version === 1`; `nodes` is list of exactly 7; each has `id`,`part`,`visible`; `part` ∈ `ApiDocLayoutParts::KEYS`; all keys present once; coerce `id` to equal `part`; `visible` to bool.

- [ ] **Step 4: Tests PASS + commit**

```bash
git commit -m "feat(api-doc): add layout tree defaults and validator"
```

---

