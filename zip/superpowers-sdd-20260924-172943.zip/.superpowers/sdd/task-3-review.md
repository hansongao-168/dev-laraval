# Task 3 Review: PageSkeletonWriter

**Reviewer:** Task-scoped gate (read-only)  
**Diff reviewed:** `/var/www/dev-laraval/.superpowers/sdd/task-3-review-package.diff` (gz168 `263af83`→`bb70ce2`, parent `693c79b`→`941fa9f`)  
**Brief:** `/var/www/dev-laraval/.superpowers/sdd/task-3-brief.md`  
**Report:** `/var/www/dev-laraval/.superpowers/sdd/task-3-report.md`

## Verdict

| Dimension | Result |
|-----------|--------|
| **Spec** | ✅ |
| **Quality** | **Approved** |

Implementation matches Task 3 brief and global M1 layout constraints (shared intro/api foreach, relative order ignored, `visible:false` omits). Writer return value is valid Blade-ish PHP with classic `api_doc_part` argument arrays. Dual-write correctly left to Task 4.

## Global constraints

| Constraint | Status | Evidence |
|------------|--------|----------|
| intro/api share one `@foreach` sections slot | ✅ | `sectionsSlot()`; emit once via `$sectionsEmitted` |
| Relative intro↔api order ignored | ✅ | Pre-scan visibility; slot at first of {intro,api}; second skipped |
| `visible:false` omits (no comment wrap) | ✅ | Non-section `continue` when `!$visible`; sections omit loop when both hidden |
| Dual-write not in this task | ✅ | Writer only; no `LayoutTreeService` / model save in diff |
| Valid Blade-ish PHP + classic `api_doc_part` args | ✅ | Matches `api-doc-page.blade.php`; `=>` restored after sanitize |

## Spec compliance (brief)

| Requirement | Status | Evidence |
|-------------|--------|----------|
| `PageSkeletonWriter::write(array $tree): string` + PHPDoc shape | ✅ | `gz168/.../PageSkeletonWriter.php` |
| Header / nav / carriers / decisions / note arg arrays match classic | ✅ | Exact strings vs `resources/views/front/api-doc-page.blade.php` |
| Sections slot with inlined `true`/`false` for intro/api | ✅ | `@if (true)` / `@if (false)` literals |
| Decisions: `@if (!empty($data['settings']['show_decisions']))` **and** only when node visible | ✅ | `decisionsBlock()`; skipped when `visible:false` |
| Shell order algorithm (walk; sections once; others at position) | ✅ | Main loop in `write()` |
| Classic outer `<div>…toast…</div>` | ✅ | Opening `<div>` + footer/toast closers |
| Sanitize inside Writer via `sanitizeBodyParts` | ✅ | Return path sanitizes `page` |
| Tests: order+hide note; hide carriers; omit foreach | ✅ | Parent `PageSkeletonWriterTest.php` matches brief |
| Commit `feat(api-doc): generate page skeleton from layout tree` | ✅ | gz168 `bb70ce2`, parent `941fa9f` (+ submodule pointer) |

**Local verification:** `php artisan test --compact tests/Unit/ApiDoc/PageSkeletonWriterTest.php` → 3 passed, 5 assertions.

## Sanitizer `=>` → `=&gt;` (implementer concern)

**Finding:** `ApiDocHtmlSanitizer::sanitizeHtml` (DOM `saveHTML`) entity-encodes `=>` in Blade/PHP arrays to `=&gt;`. Without restore, compiled Blade emits invalid PHP (`=` + `&` + `gt`, not `T_DOUBLE_ARROW`).

**Writer mitigation:** `str_replace('=&gt;', '=>', $sanitized)` before return.

| Check | Result |
|-------|--------|
| Raw sanitizer on `['settings' => $x]` | Produces `=&gt;` |
| `write()` final output | Contains `=>`, no `=&gt;` |
| `Blade::compileString(write(...))` | Succeeds; compiled PHP keeps `=>` |
| Would break Blade if restore omitted? | **Yes** (runtime parse failure) |

**Verdict on this concern:** Not Critical for Task 3 — Writer contract returns renderable Blade. Remains **Important** as a fragile workaround (see Issues).

## Quality

**Strengths**

- Clear separation: visibility pre-scan, sections-slot once, classic arg helpers as private methods.
- Lazy wrap/main open mirrors classic nesting for the default tree; footer/toast always present.
- Decisions correctly combine tree visibility with classic `show_decisions` gate.
- Note omitted by default; args `['note' => $data['note'] ?? [], 'lang' => $lang]` when visible (classic page has no note — reasonable inference).
- Spot-checked: intro-only → `@if (true)` + `@if (false)`; decisions hidden omits wrap; note visible emits call.
- `declare(strict_types=1)`, constructor DI, final class; Pint reported clean in task report.

### Critical

- None. Generated page from `write()` does **not** break Blade when rendered (restore in place).

### Important (non-blocking for Task 3 merge; fix before / in Task 4 dual-write)

1. **`=&gt;` restore is untested and undone by model save**
   - File: `PageSkeletonWriter.php` (~L115–116); `ApiDocTemplate` saving hook re-runs `sanitizeBodyParts` without restore.
   - Why: Brief tests only assert `api_doc_part('header'` — they pass even if `=&gt;` remains. Task 4 dual-write → model `saving` sanitizes again → stored `body_parts.page` would be invalid Blade.
   - Fix: Prefer sanitizer exemption / Blade-safe path for `page` (or restore in sanitizer for known Blade keys); add assertion `assertStringContainsString("'settings' =>", $html)` (and/or Blade compile smoke). Do **not** rely on Writer-only restore once pages persist.

2. **Coverage gaps (report acknowledged)**
   - No tests for partial intro/api visibility, decisions hide, note visible, or `=>` integrity.
   - Behavior verified manually in this review; lock with tests when Task 4 consumes Writer.

### Minor (non-blocking)

1. **DOM whitespace collapse** — Indentation from Writer is flattened by `saveHTML`; cosmetic only.
2. **Arbitrary reorder vs classic chrome** — If sections (or other main content) precede `nav`/`header` in the tree, nav can land inside `<main>` and header can appear mid-shell. Default order is fine; full reorder may need chrome invariants later.
3. **Note args** — Inferred (classic shell has no note); confirm when UI enables note visibility.

## Commit hygiene

- gz168: single feat commit, `PageSkeletonWriter.php` only — good.
- Parent: submodule pointer `263af83`→`bb70ce2` + unit test — good.
- No dual-write / unrelated files in package.

## Gate decision

| Gate | Result |
|------|--------|
| Task-scoped spec | **PASS** (Spec ✅) |
| Quality (task scope) | **PASS** (Approved) |
| Ready to merge (Task 3) | **YES** |

## Follow-ups (out of scope for this gate)

- Task 4: dual-write must not re-break `=>` via unsanitizer-aware model save.
- Harden Writer tests: `=>` present, partial intro/api, decisions/note visibility.
- Longer-term: fix `ApiDocHtmlSanitizer` for Blade-bearing `page` parts instead of Writer `str_replace`.
