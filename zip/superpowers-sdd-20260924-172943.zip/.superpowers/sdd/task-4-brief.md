### Task 4: LayoutTreeService

**Files:**
- Create: `gz168/ApiDoc/src/Layout/LayoutTreeService.php`
- Test: `tests/Feature/ApiDoc/LayoutTreeServiceTest.php`

**Interfaces:**
```php
final class LayoutTreeService
{
    /**
     * @param  array<string,mixed>  $tree
     */
    public function save(ApiDocTemplate $template, array $tree): ApiDocTemplate;

    /**
     * Page HTML used for front render when visual enabled.
     */
    public function resolveEffectivePage(ApiDocTemplate $template): ?string;
}
```

`save`: validate → set `layout_tree` → set `body_parts['page']` from Writer → `save()` model → flush cache via existing `ApiDocCacheManager` (same as other template saves if a helper exists; else call whatever Edit page uses).

`resolveEffectivePage`: if not `layout_visual_enabled`, return null (caller keeps existing resolve). If enabled: non-empty `body_parts.page` return it; else if tree present validate+Writer without persisting; else Defaults+Writer without persisting.

- [ ] **Step 1: Feature tests**

```php
#[Test]
public function save_dual_writes_tree_and_page(): void
{
    $this->seed(ApiDocTemplateSeeder::class);
    $t = ApiDocTemplate::query()->where('code', 'classic')->firstOrFail();
    $tree = LayoutTreeDefaults::tree();
    app(LayoutTreeService::class)->save($t, $tree);
    $t->refresh();
    $this->assertNotNull($t->layout_tree);
    $this->assertStringContainsString("api_doc_part('header'", (string) ($t->body_parts['page'] ?? ''));
}

#[Test]
public function disabled_visual_does_not_require_tree_for_runtime_page(): void
{
    $this->seed(ApiDocTemplateSeeder::class);
    $t = ApiDocTemplate::query()->where('code', 'classic')->firstOrFail();
    $t->layout_visual_enabled = false;
    $t->save();
    $this->assertNull(app(LayoutTreeService::class)->resolveEffectivePage($t));
}
```

- [ ] **Step 2: Implement + PASS + commit**

```bash
git commit -m "feat(api-doc): add LayoutTreeService dual-write"
```

---

