# Final Review: ApiDoc Display Modes

**Branch:** `feat/apidoc-display-modes`  
**Parent range:** `6e72c500` → `75a23d09`  
**gz168 range:** `40f8c31` → `eb80bcf`  
**Diff package:** `.superpowers/sdd/final-review-package.diff`  
**Spec:** `docs/dev-laraval/superpowers/specs/2026-09-14-apidoc-display-modes-design.md`  
**Plan:** `docs/dev-laraval/superpowers/plans/2026-09-14-apidoc-display-modes.md`  
**Ledger:** `.superpowers/sdd/progress.md`  
**Verification:** `php artisan test --compact tests/Feature/ApiDoc/ tests/Unit/ApiDoc/` → **28 passed** (61 assertions)

---

## Overall verdict

**Request changes**

Display-mode persistence, resolution, front switcher, in-mode rendering, legacy `?lang=`, settings cleanup, and model invariants are in good shape and well covered by tests. The branch does **not** yet complete Spec §4.1 / Plan Task 7 for **trilingual admin entry**: English tabs are absent at call sites, and `LocalizedBodyFields` is never wired. Those are Important merge blockers.

---

## Plan alignment

| Spec / plan item | Status | Notes |
| --- | --- | --- |
| Content JSON `{fr,zh,en}` + `LocalizedString` normalize | ✅ | Cast and mode pick/format implemented |
| Table `api_doc_display_modes` + seed 5 modes (`fr_zh` = `[fr,zh]`) | ✅ | Migration, model, factory, seeder, seed-from-html hook |
| `ApiDocDisplayModeResolver` + legacy map + `mode` over `lang` | ✅ | Tests for both→`fr_zh`, mode preference, inactive→default |
| Renderer + cache keys by mode code; body HTML not double-escaped | ✅ | `localize` / `localizeBody` + `formatModeHtml`; flush seed+legacy codes |
| Front header from `activeOrdered()`; `?mode=` / `?lang=` | ✅ | Livewire `$mode`, inactive omitted test |
| Filament Display Mode resource + invariants + soft-protect codes | ✅ | Model `saving`/`deleting`; Create/Edit sync + flush |
| Sync `default_locale` from default mode `locales[0]` | ✅ | Resolver + page hooks; unit-ish feature coverage (manual sync in test) |
| Settings page drops misleading default-locale control | ✅ | Placeholder → Display Mode resource |
| Deprecate enum front usage | ✅ | Enums `@deprecated`; switcher is DB-driven |
| Ignore `template_key` at runtime | ✅ | Hidden field only |
| Permissions reuse `api-doc.view` / `api-doc.update` | ✅ | `ApiDocAuthorization` on resource |
| Admin Tabs 法文 \| 中文 \| **英文** for all `{fr,zh,en}` fields | ❌ | EN tab only if `$enLabel !== null`; **no call site passes it** |
| Body: shared `content_format` + Markdown/Rich editors per locale | ❌ | `LocalizedBodyFields` exists but **zero call sites**; paras/notes/etc. still `LocalizedKeyValue` TextInputs, no format Select |
| Unit: in-mode fallback + multi-locale spans | ✅ | `LocalizedStringFormatTest` |
| Feature: CRUD invariants, header, mode/lang, cache write-path | ✅ / partial | Strong on modes/front; Filament page-hook sync not asserted |
| `ensureInvariant()` | ⚠️ | Implemented; **never called**; untested |

Tasks 1–6 and 8 meet their core contracts. Task 7 is only partially delivered (component shape correct; integration incomplete).

---

## Critical findings

_None._

No security, data-loss, or hard runtime crash paths identified in the packaged diff. Front resolution fails closed to the default mode; model guards block zero-active / zero-default states.

---

## Important findings (fix before merge)

### 1. English admin tabs never appear at call sites

**Where:** `LocalizedKeyValue::make(...)` across Filament resources/relation managers (e.g. `ApiDocSectionResource`, `ParasRelationManager`, `ApiDocDecisionResource`, …); implementation in `LocalizedKeyValue.php` (EN tab gated on `$enLabel !== null`).

**Why:** Spec §4.1 and Plan Task 7 require Tabs **法文 | 中文 | 英文**. Call sites pass only FR/ZH labels, so operators cannot edit `en` in the admin UI even though storage, rendering, and seeded display modes include English.

**Fix:** Always include the EN tab (match the plan snippet), or pass `enLabel` at every `{fr,zh,en}` call site. Prefer making EN default-on in `LocalizedKeyValue::make` so omission cannot regress.

### 2. `LocalizedBodyFields` is dead code; body forms still short TextInputs

**Where:** `LocalizedBodyFields.php` (only definition); contrast `ParasRelationManager`, `NotesRelationManager`, decision/quickstart forms still using `LocalizedKeyValue`. Renderer already calls `localizeBody(..., $content_format)`.

**Why:** Spec §4.1 and Plan Task 7 Step 2 require format Select + MarkdownEditor/RichEditor per locale for 正文. Front rendering respects `content_format`, but admins cannot set format or use the intended editors. Task 7 review already flagged this; branch head (`eb80bcf`) did not close it.

**Fix:** Spread `...LocalizedBodyFields::make(...)` on fields that own `content_format` (paras `text`, notes `body`, decisions `body`, quickstart `description`, param descriptions as applicable). Revisit `required()` semantics when replacing KeyValue bodies.

### 3. Create/Edit default sync is untested end-to-end

**Where:** `CreateApiDocDisplayMode` / `EditApiDocDisplayMode` `syncDefaultAndFlush()`; test `setting_default_syncs_settings_locale` manually clears rivals and calls `syncSettingDefaultLocale`.

**Why:** Ledger / Task 6 Important. Multiple `is_default` rows remain possible via raw Eloquent until page hooks run; the only automated sync assertion bypasses Filament.

**Fix:** Add a Livewire/resource feature test (or exercise the page hooks) that sets default via Create/Edit and asserts single default + `ApiDocSetting.default_locale`.

---

## Minor findings

1. **`ensureInvariant()` unused** — Plan “Produces” method never invoked; recovery path untested (ledger Task 3).
2. **Seeder does not clear `is_default` on non-seed rows** — Re-seed of five codes is fine; a custom defaulted mode can leave dual defaults until admin/resolver behavior intervenes (ledger Task 2).
3. **`SeedFromHtmlCommand --fresh` omits `api_doc_display_modes`** — Harmless with upsert; asymmetric with other tables (ledger Task 2).
4. **Custom mode cache keys on non-tagged stores** — Flush list is seed+legacy only (matches Spec §5.4); custom `code` payloads can linger until TTL on file/DB cache.
5. **Edit Repeater fill smoke** — `simple(Select)` likely stores a flat list (fill may work without `mutateFormDataBeforeFill`); still unverified in admin (ledger Task 6). Confirm once in UI.
6. **Settings save does not assert `default_locale` retention** — Behavior looks correct (field omitted from form state); optional regression test (ledger Task 8).
7. **`RuntimeException` for invariant violations** — Correct for model tests; Filament UX may be harsh vs `ValidationException`/Notification.
8. **Alpine still names state `lang`**; layout description hard-codes `FR / ZH / EN` (Task 5 minors).
9. **Task 8 commit scope** — `ApiDocSection::newFactory()` + `duplicate()` are justified by the green suite but wider than “settings + deprecate enums.”
10. **Dead enum `options()` / `values()`** — Retained and unused; fine for a later cleanup.

---

## Ledger minors — fix before merge vs defer

| Ledger minor | Triage | Rationale |
| --- | --- | --- |
| Task 7: BodyFields wired / EN tabs (call sites) | **Fix before merge** | Spec §4.1 incomplete; see Important #1–#2 |
| Task 6: Filament hook sync test | **Fix before merge** | Important #3; cheap insurance on default+settings contract |
| Task 6: Repeater fill smoke | **Defer** (after one manual edit open) | Likely OK with Filament `simple()` flat state; confirm once |
| Task 3: `ensureInvariant` / sync untested | **Defer** sync covered partially; **defer** `ensureInvariant` | Sync: prefer Important #3 page test; `ensureInvariant` unused |
| Task 2: seeder rival defaults | **Defer** | Seed rows reset their own flags; custom dual-default is edge |
| Task 2: `--fresh` table list | **Defer** | Cosmetic asymmetry |
| Task 4: `_misc`→`misc`, legacy cache keys, double resolve | **Defer** | No functional breakage observed |
| Task 5: `switchMode` interaction test, Alpine rename | **Defer** | Mount/header coverage exists |
| Task 8: settings `default_locale` regression test | **Defer** | Nice-to-have |
| Task 8: `newFactory` / `duplicate` in commit | **Defer** | Documented; not a product defect |

---

## Strengths

- Clear separation: content locales vs DB display modes vs unused `template_key`.
- Resolver legacy map (`both`→`fr_zh`) and silent fallback for bad/inactive modes match Spec §5.1–5.2.
- In-mode-only fallback is unit-tested; combined HTML spans match Spec §5.3 temporary layout.
- Model-level invariants + protected seed codes are stronger than form-only checks.
- Settings page correctly stops treating `default_locale` as the front default source.
- ApiDoc feature/unit suite green at 28 tests on review run.

---

## Recommended merge gate

1. Ship EN tabs on all localized admin fields (Important #1).
2. Wire `LocalizedBodyFields` (or equivalent) for `content_format`-backed bodies (Important #2).
3. Add Filament Create/Edit test for default sync + `default_locale` (Important #3).
4. Optional before merge: one manual edit of a display mode’s locale Repeater to confirm fill.

Then re-run `php artisan test --compact tests/Feature/ApiDoc/ tests/Unit/ApiDoc/` and reconsider for **Approve** / **Approve with nits**.
