# Task 9 Report: Driver `grapesjs`

**Date:** 2026-09-18  
**Branch:** `feat/apidoc-display-modes` (gz168 + parent)  
**Status:** Complete

## Summary

GrapesJS layout editor shell for ApiDoc templates: Vite-bundled editor (7 blocks only, `storageManager: false`), Livewire apply/save via shared `LayoutTreeService`, and read-only selected-part preview (`iframe` srcdoc from sanitized `body_parts` / file fallback).

## Files Created / Updated

| Path | Role |
| --- | --- |
| `package.json` / `package-lock.json` | `grapesjs@^0.23.6` dependency |
| `vite.config.js` | Input `resources/js/api-doc-layout-grapes.js` |
| `resources/js/api-doc-layout-grapes.js` | Vite entry importing package editor |
| `gz168/ApiDoc/resources/js/layout/grapes-editor.js` | 7 blocks; load tree; apply → Livewire; reject unknown |
| `gz168/.../template-layout-editor.blade.php` | Grapes canvas + `@vite` + preview panel |
| `gz168/.../ApiDocTemplateLayoutEditorPage.php` | `selectedPart`, `applyLayoutFromGrapes`, preview props |
| `tests/.../ApiDocTemplateLayoutEditorPageTest.php` | Grapes smoke + save + preview |

## Test Cases

1. **grapesjs_editor_loads_root_and_save_layout_persists_tree** — 200, `#api-doc-grapes-root`, `applyLayoutFromGrapes` + `saveLayout` without browser JS.
2. **grapesjs_selected_part_preview_reads_body_parts** — `selectedPart` → sanitized HTML preview.
3. Existing livewire_page / gate tests unchanged (still pass).

## Commits

| Repo | SHA | Message |
| --- | --- | --- |
| gz168 | `a5e8058` | feat(api-doc): grapesjs layout editor shell |
| parent | `767084f` | feat(api-doc): grapesjs layout editor shell |

Report under `.superpowers/sdd/` (gitignored). No push.

## Verification Command

```bash
npm run build
php artisan test --compact tests/Feature/ApiDoc/ApiDocTemplateLayoutEditorPageTest.php
```

**Evidence (2026-09-18):** `npm run build` OK (grapes chunk ~1.1 MB). PHPUnit: 5 passed, 20 assertions. Pint: passed.

## Concerns / Follow-ups

- Grapes chunk is large (~1.1 MB); acceptable for admin-only layout page; could code-split later.
- Tests use `withoutVite()` so PHPUnit does not require `public/build` (gitignored).
- Canvas does not yet prevent duplicate parts in the UI; validator rejects incomplete/illegal trees on apply/save.
- Read-only preview uses raw/sanitized part source (not full `ApiDocTemplateViewResolver` render with front data).
