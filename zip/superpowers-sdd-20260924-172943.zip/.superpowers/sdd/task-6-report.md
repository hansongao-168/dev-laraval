# Task 6 Report: Filament layout fields + page lock + resolveEffectivePage

**Date:** 2026-09-18  
**Branch:** `feat/apidoc-display-modes` (gz168 + parent)  
**Status:** Complete

## Summary

Edit ApiDoc template form gains a「布局」section (`layout_visual_enabled` + `layout_editor`) gated by `ApiDocLayoutGate`. When visual layout is on, the `body_parts.page` textarea is disabled and not dehydrated; `EditApiDocTemplate::mutateFormDataBeforeSave` also restores the stored `page`. Front render of the `page` part prefers `LayoutTreeService::resolveEffectivePage` when it returns a non-empty string (visual enabled), so an empty DB page regenerates from the tree instead of the classic blade fallback.

## TDD Flow

| Phase | Result |
| --- | --- |
| RED | Missing form fields; empty page + visual fell through to file (carriers visible) |
| GREEN | 2 passed, 12 assertions |
| Related | Resource + Render + LayoutTreeService — 11 passed, 42 assertions |
| Pint | Passed (`vendor/bin/pint --dirty --format agent`) |

## Files Created / Updated

| Path | Role |
| --- | --- |
| `gz168/ApiDoc/src/Filament/Resources/ApiDocTemplateResource.php` | Section「布局」; page textarea lock |
| `gz168/ApiDoc/src/Filament/Resources/ApiDocTemplateResource/Pages/EditApiDocTemplate.php` | Strip/restore `page` when visual enabled |
| `gz168/ApiDoc/src/Services/ApiDocTemplateViewResolver.php` | Prefer `resolveEffectivePage` for `page` |
| `tests/Feature/ApiDoc/ApiDocTemplateLayoutLockTest.php` | Edit save ignores page tampering |
| `tests/Feature/ApiDoc/ApiDocTemplateLayoutRenderTest.php` | Hidden carriers absent on `/api-doc` |

## Implementation Notes

### Filament form

- Toggle / Select disabled when `! ApiDocLayoutGate::allows(auth()->user())`.
- Toggle is `live()` so the page textarea reacts immediately.
- `body_parts.page`: `disabled` + `dehydrated(false)` while visual enabled.

### Edit page

`mutateFormDataBeforeSave` forces `body_parts.page` back to the record’s original when visual is enabled (defense in depth alongside model saving hooks).

### ViewResolver

On `part === 'page'`, load the template by skin key and, if `resolveEffectivePage` returns a non-empty string, Blade-render that. Otherwise keep prior body_parts → file fallback behavior.

## Test Cases

1. **enabled_visual_ignores_page_tampering_on_edit** — form fields exist; fillForm TAMPER + save; page unchanged.
2. **visual_layout_hides_carriers_when_tree_marks_invisible** — save tree with carriers hidden, clear `page`, enable visual; `GET /api-doc` must not contain `id="transporteurs"` (proves tree regeneration over file fallback).

## Commits

| Repo | SHA | Message |
| --- | --- | --- |
| gz168 | `d332825` | feat(api-doc): filament layout fields and page lock |
| parent | `9773d72` | feat(api-doc): filament layout fields and page lock |

Parent commit includes submodule pointer update + feature tests. Report lives under `.superpowers/sdd/` (gitignored). No push.

## Verification Command

```bash
php artisan test --compact tests/Feature/ApiDoc/ApiDocTemplateLayoutLockTest.php tests/Feature/ApiDoc/ApiDocTemplateLayoutRenderTest.php
```

**Evidence (2026-09-18):** 2 passed, 12 assertions. Related suite: 11 passed, 42 assertions.

## Concerns / Follow-ups

- Boost `search-docs` / `artisan docs` returned HTTP 403 in this environment; Filament field APIs were mirrored from existing Resources (Select/Toggle/`Get` patterns).
- `ApiDocPage::assertPartAvailable('page')` still accepts the classic blade file when `body_parts.page` is empty; visual regeneration is applied later in ViewResolver. Skins without a file fallback and an empty page would still fail the pre-check unless that assertion is taught about `resolveEffectivePage`.
- Layout Toggle/Select remain visible (but disabled) without the layout gate; unauthorized writes stay blocked by model hooks.
