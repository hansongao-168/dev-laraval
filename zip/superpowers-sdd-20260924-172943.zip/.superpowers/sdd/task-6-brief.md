### Task 6: Filament Resource fields + page lock + wire resolveEffectivePage

**Files:**
- Modify: `gz168/ApiDoc/src/Filament/Resources/ApiDocTemplateResource.php`
- Modify: `gz168/ApiDoc/src/Filament/Resources/ApiDocTemplateResource/Pages/EditApiDocTemplate.php` (mutateFormDataBeforeSave strip page if enabled)
- Modify: `gz168/ApiDoc/src/Services/ApiDocTemplateViewResolver.php` (or page render path) to use `LayoutTreeService::resolveEffectivePage` when non-null
- Test: `tests/Feature/ApiDoc/ApiDocTemplateLayoutLockTest.php`
- Test: `tests/Feature/ApiDoc/ApiDocTemplateLayoutRenderTest.php`

- [ ] **Step 1: Add form controls** on Edit (Section「布局」):
  - `Toggle::make('layout_visual_enabled')->disabled(fn () => ! ApiDocLayoutGate::allows(auth()->user()))`
  - `Select::make('layout_editor')->options(collect(ApiDocLayoutEditor::cases())->mapWithKeys(...))->disabled(...)`
  - For `body_parts.page` Textarea: `->disabled(fn (Get $get) => (bool) $get('layout_visual_enabled'))` and `->dehydrated(fn (Get $get) => ! (bool) $get('layout_visual_enabled'))`

- [ ] **Step 2: Tests**

```php
#[Test]
public function enabled_visual_ignores_page_tampering_on_edit(): void
{
    $this->seed(ApiDocTemplateSeeder::class);
    $this->actingAsFilamentAdmin(); // has all perms
    $t = ApiDocTemplate::query()->where('code', 'classic')->firstOrFail();
    $tree = LayoutTreeDefaults::tree();
    app(LayoutTreeService::class)->save($t, $tree);
    $t->layout_visual_enabled = true;
    $t->save();
    $before = $t->fresh()->body_parts['page'];

    Livewire::test(EditApiDocTemplate::class, ['record' => $t->getKey()])
        ->fillForm([
            'body_parts.page' => '<div>TAMPER</div>',
            'layout_visual_enabled' => true,
        ])
        ->call('save')
        ->assertHasNoFormErrors();

    $this->assertSame($before, $t->fresh()->body_parts['page']);
    $this->assertStringNotContainsString('TAMPER', (string) $t->fresh()->body_parts['page']);
}
```

Render test: enable visual, hide carriers in tree via Service, hit `/api-doc` (or preview) and assert carriers marker absent — use existing front test patterns in `ApiDocTemplateRenderTest.php`.

- [ ] **Step 3: Implement ViewResolver hook** — when resolving `page` part for a template with visual enabled, prefer `resolveEffectivePage` string over empty file fallback.

- [ ] **Step 4: PASS + commit**

```bash
git commit -m "feat(api-doc): filament layout fields and page lock"
```

---

